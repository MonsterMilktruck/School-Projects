import java.util.Arrays;

import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class ABCDGuesser1 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser1() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        double userInput = -1.0;
        String userInputString;
        /*
         * repeats until user enters a positive number
         */
        while (userInput < 0) {
            out.print("Enter a positive number: ");
            userInputString = in.nextLine();
            /*
             * checks if the input can be parsed into a double so an error
             * doesn't occur
             */
            if (FormatChecker.canParseDouble(userInputString)) {
                userInput = Double.parseDouble(userInputString);
            }
        }
        return userInput;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {
        double userInput = -1.0;
        String userInputString;
        /*
         * repeats until user enters a positive number and it isnt 1
         */
        while (userInput < 0 || userInput == 1) {
            out.print("Enter a positive number but not 1: ");
            userInputString = in.nextLine();
            /*
             * checks if the input can be parsed into a double so an error
             * doesn't occur
             */
            if (FormatChecker.canParseDouble(userInputString)) {
                userInput = Double.parseDouble(userInputString);
            }
        }
        return userInput;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * creates two arrays - one for all the possible exponent values and
         * another for all of the best values found to be used later
         */
        double[] exponentValues = new double[] { -5.0, -4.0, -3.0, -2.0, -1.0,
                -0.5, -(1 / 3), -0.25, 0, 0.25, (1 / 3), 0.5, 1.0, 2.0, 3.0,
                4.0, 5.0 };
        double[] bestExponentValues = new double[4];
        /*
         * asks user for what the constant to be determined should be
         */
        out.print("What is the number that should be evaluated? ");
        double mew = getPositiveDouble(in, out);
        /*
         * asks user for what the 4 personal numbers should be
         */
        out.println("What are your 4 personal numbers?");
        out.print("Number 1 - ");
        double personalOne = getPositiveDoubleNotOne(in, out);
        out.print("Number 2 - ");
        double personalTwo = getPositiveDoubleNotOne(in, out);
        out.print("Number 3 - ");
        double personalThree = getPositiveDoubleNotOne(in, out);
        out.print("Number 4 - ");
        double personalFour = getPositiveDoubleNotOne(in, out);
        /*
         * Uses nested while loops to "brute force" all combinations of numbers
         * for the exponents possible
         */
        int count1 = 0;
        double closeToMew = 0.0;
        while (count1 < 17) {
            int count2 = 0;
            while (count2 < 17) {
                int count3 = 0;
                while (count3 < 17) {
                    int count4 = 0;
                    while (count4 < 17) {
                        /*
                         * calculates the total of the values determined by the
                         * nested while loops and the count variables
                         */
                        double temp = Math.pow(personalOne,
                                exponentValues[count1])
                                * Math.pow(personalTwo, exponentValues[count2])
                                * Math.pow(personalThree,
                                        exponentValues[count3])
                                * Math.pow(personalFour,
                                        exponentValues[count4]);
                        /*
                         * checks if the recently calculated value is closer to
                         * the target value then executes if it is
                         */
                        if (Math.abs(mew - closeToMew) > Math.abs(mew - temp)) {
                            /*
                             * updates the new best exponents that gets closest
                             * to the target value
                             */
                            bestExponentValues[0] = exponentValues[count1];
                            bestExponentValues[1] = exponentValues[count2];
                            bestExponentValues[2] = exponentValues[count3];
                            bestExponentValues[3] = exponentValues[count4];
                            /*
                             * checks if the recently calculated value is closer
                             * to the target value then executes if it is
                             */
                            closeToMew = temp;
                        }
                        count4++;
                    }
                    count3++;
                }
                count2++;
            }
            count1++;
        }
        /*
         * prints the array of best exponents going from the first number to the
         * last
         */
        out.print("Best Exponents: ");
        out.println(Arrays.toString(bestExponentValues));
        /*
         * prints the best estimation
         */
        out.println("Best Estimation: " + closeToMew);
        /*
         * prints the percentage of error
         */
        out.print("Error: ");
        out.print(((Math.abs(mew - closeToMew)) / mew * 100), 2, false);
        out.println("%");
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
