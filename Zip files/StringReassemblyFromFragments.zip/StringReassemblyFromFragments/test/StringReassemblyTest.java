import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class StringReassemblyTest {

    @Test
    public void combination_Osu_uIsGreat() {
        String r = "Osu ";
        String rExpected = "Osu ";
        String s = "u is great";
        String sExpected = "u is great";
        int b = 2;
        int bExpected = 2;
        String resultExpected = "Osu is great";
        String result = StringReassembly.combination(r, s, b);

        assertEquals(rExpected, r);
        assertEquals(sExpected, s);
        assertEquals(bExpected, b);
        assertEquals(resultExpected, result);
    }

    @Test
    public void combination_AGCTGTTTTCGTT_TTTCGTTATACAT() {
        String r = "AGCTGTTTTCGTT";
        String rExpected = "AGCTGTTTTCGTT";
        String s = "TTTCGTTATACAT";
        String sExpected = "TTTCGTTATACAT";
        int b = 7;
        int bExpected = 7;
        String resultExpected = "AGCTGTTTTCGTTATACAT";
        String result = StringReassembly.combination(r, s, b);

        assertEquals(rExpected, r);
        assertEquals(sExpected, s);
        assertEquals(bExpected, b);
        assertEquals(resultExpected, result);
    }

    @Test
    public void combination_ComputerScience_Science() {
        String r = "Computer Science";
        String rExpected = "Computer Science";
        String s = "Science";
        String sExpected = "Science";
        int b = 7;
        int bExpected = 7;
        String resultExpected = "Computer Science";
        String result = StringReassembly.combination(r, s, b);

        assertEquals(rExpected, r);
        assertEquals(sExpected, s);
        assertEquals(bExpected, b);
        assertEquals(resultExpected, result);
    }

    @Test
    public void combination_blank() {
        String r = "";
        String rExpected = "";
        String s = "";
        String sExpected = "";
        int b = 0;
        int bExpected = 0;
        String resultExpected = "";
        String result = StringReassembly.combination(r, s, b);

        assertEquals(rExpected, r);
        assertEquals(sExpected, s);
        assertEquals(bExpected, b);
        assertEquals(resultExpected, result);
    }

    @Test
    public void addToSetAvoidingSubstrings_blank() {
        Set<String> r = new Set2();
        r.add("ok");
        r.add("he went");
        Set<String> rExpected = new Set2();
        rExpected.add("ok");
        rExpected.add("he went");
        String s = "";
        String sExpected = "";
        StringReassembly.addToSetAvoidingSubstrings(r, s);

        assertEquals(rExpected, r);
        assertEquals(sExpected, s);
    }

    @Test
    public void addToSetAvoidingSubstrings_routine() {
        Set<String> r = new Set2();
        r.add("why did he go");
        r.add("because he did not want to");
        Set<String> rExpected = new Set2();
        rExpected.add("why did he go");
        rExpected.add("because he did not want to");
        String s = "to";
        String sExpected = "to";
        StringReassembly.addToSetAvoidingSubstrings(r, s);

        assertEquals(rExpected, r);
        assertEquals(sExpected, s);
    }

    @Test
    public void addToSetAvoidingSubstrings_routine2() {
        Set<String> r = new Set2();
        r.add("you went");
        r.add("he came");
        Set<String> rExpected = new Set2();
        rExpected.add("you went");
        rExpected.add("he came");
        rExpected.add("she left");
        String s = "she left";
        String sExpected = "she left";
        StringReassembly.addToSetAvoidingSubstrings(r, s);

        assertEquals(rExpected, r);
        assertEquals(sExpected, s);
    }

    @Test
    public void linesFromInput_Cheer() {
        Set<String> resultExpected = new Set2();
        resultExpected.add("Bucks -- Beat");
        resultExpected.add("Go Bucks");
        resultExpected.add("o Bucks -- B");
        resultExpected.add("Beat Mich");
        resultExpected.add("Michigan~");
        SimpleReader inFile = new SimpleReader1L("Cheer");
        Set<String> result = StringReassembly.linesFromInput(inFile);

        assertEquals(resultExpected, result);
    }

    @Test
    public void printWithLineSeparators_blank() {
        String r = "";
        String rExpected = "";
        SimpleWriter out = new SimpleWriter1L("test.txt");
        SimpleWriter outExpected = new SimpleWriter1L("expectedBlank");
        outExpected.println();
        StringReassembly.printWithLineSeparators(r, out);
        SimpleReader checkerTest = new SimpleReader1L("test2.txt");
        SimpleReader checkerExpected = new SimpleReader1L("expectedRoutine");
        boolean result = true;
        while (!checkerTest.atEOS()) {
            if (!checkerTest.nextLine().equals(checkerExpected.nextLine())) {
                result = false;
            }
        }

        assertEquals(true, result);
        assertEquals(r, rExpected);
    }

    @Test
    public void printWithLineSeparators_Routine() {
        String r = "He went to the store~what was that noise?";
        String rExpected = "He went to the store~what was that noise?";
        SimpleWriter out = new SimpleWriter1L("test2.txt");
        SimpleWriter outExpected = new SimpleWriter1L("expectedRoutine");
        outExpected.println("He went to the store");
        outExpected.println("what was that noise?");
        StringReassembly.printWithLineSeparators(r, out);
        SimpleReader checkerTest = new SimpleReader1L("test2.txt");
        SimpleReader checkerExpected = new SimpleReader1L("expectedRoutine");
        boolean result = true;
        while (!checkerTest.atEOS()) {
            if (!checkerTest.nextLine().equals(checkerExpected.nextLine())) {
                result = false;
            }
        }

        assertEquals(true, result);
        assertEquals(r, rExpected);
    }
}
