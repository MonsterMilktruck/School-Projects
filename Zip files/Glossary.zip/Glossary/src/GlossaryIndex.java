import java.util.Comparator;

import components.map.Map;
import components.map.Map2;
import components.queue.Queue;
import components.queue.Queue2;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Program to test static methods {@code generateElements} and
 * {@code nextWordOrSeparator}.
 *
 * @author Brady Scott
 *
 */
public final class GlossaryIndex {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private GlossaryIndex() {
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param charSet
     *            the {@code Set} to be replaced
     * @replaces charSet
     * @ensures charSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> charSet) {
        for (int i = 0; i < str.length() - 1; i++) {
            charSet.add(str.charAt(i));
        }
    }

    /**
     * Outputs all html file contents to their respective files
     *
     * @param folder
     *            the folder outputted to
     * @param termsAndDef
     *            Map containing terms and definitions
     * @param separators
     *            list of word separators
     * @param terms
     *            Queue containing all of the terms
     * @updates index.html
     * @ensures index.html = [#index.html] * [terms in a list linked to pages]
     */
    private static void outputElements(String folder, Set<Character> separators,
            Map<String, String> termsAndDef, Queue<String> terms) {
        SimpleWriter indexOut = new SimpleWriter1L(folder + "/index.html");
        //prints all of the term's html pages
        outputTermHTMLFiles(termsAndDef, separators, folder);
        indexOut.println("<html><head><title>Glossary</title>"
                + "</head><body><h1>Glossary</h1><hr /><h3></h3><ul>");
        //loops through and lists each term in alphabetical order in the index
        while (terms.length() > 0) {
            String text = terms.dequeue();
            indexOut.println(
                    "<li><a href=\"" + text + ".html\">" + text + "</a></li>");
        }
        indexOut.println("</ul></body></html>");
    }

    /**
     * Compare {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.compareTo(o2);
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        String result = "";
        int count = 0;
        if (!separators.contains(text.charAt(position))) {
            for (int i = position + 1; i < text.length(); i++) {
                if (separators.contains(text.charAt(i)) && count == 0) {
                    result = text.substring(position, i);
                    count++;
                }
            }
            if (count == 0) {
                result = text.substring(position);
            }
        } else {
            for (int z = position + 1; z < text.length(); z++) {
                if (!separators.contains(text.charAt(z)) && count == 0) {
                    for (int r = position; r < z; r++) {
                        result = result + separators.remove(text.charAt(r));
                        separators.add(text.charAt(r));
                    }
                    count++;
                }
            }

            if (count == 0) {
                for (int r = position; r < text.length(); r++) {
                    result = result + separators.remove(text.charAt(r));
                    separators.add(text.charAt(r));
                }
            }
        }
        return result;

    }

    /**
     * Outputs all html file contents for each term
     *
     * @param folder
     *            the folder outputted to
     * @param termsAndDef
     *            Map containing terms and definitions
     * @param separators
     *            list of word separators
     * @updates [term].html
     * @ensures [term].html = [#[term].html] * [term] * [definition]
     */
    private static void outputTermHTMLFiles(Map<String, String> termsAndDef,
            Set<Character> separators, String folder) {
        //loops through the terms and outputs their individual html files
        for (Map.Pair<String, String> input : termsAndDef) {
            SimpleWriter fileWriter = new SimpleWriter1L(
                    folder + "/" + input.key() + ".html");
            fileWriter.println("<html><head><title>book</title>");
            fileWriter.println("</head><body><h2><b><i><font color=\"red\">"
                    + input.key() + "</font></i></b></h2>");
            fileWriter.println("<blockquote>");
            int pos = 0;
            while (pos < input.value().length()) {
                //gets next word/separator
                String token = nextWordOrSeparator(input.value(), pos,
                        separators);
                if (!separators.contains(token.charAt(0))) {
                    boolean toPrint = false;
                    for (Map.Pair<String, String> checkMap : termsAndDef) {
                        if (checkMap.key().equals(token)) {
                            toPrint = true;
                        }
                    }
                    if (toPrint) {
                        fileWriter.print("<a href=\"" + token + ".html\">"
                                + token + "</a>");
                    } else {
                        fileWriter.print(token);
                    }

                } else {
                    fileWriter.print(token);
                }

                pos += token.length();
            }

            fileWriter.println(
                    "</blockquote><hr /><p>Return to <a href=\"index.html\">index</a>.</p></body></html>");
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        /*
         * Define separator characters for test
         */
        final String separatorStr = " \t,";
        Set<Character> separatorSet = new Set1L<>();
        Queue<String> terms = new Queue2();
        Map<String, String> termsAndDef = new Map2();
        Comparator<String> order = new StringLT();
        generateElements(separatorStr, separatorSet);
        /*
         * Open input and output streams and take in input file/output folder
         */
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        out.print("type in the file name you want to draw from: ");
        String inFile = in.nextLine();
        out.print("type in the file name you want to output to: ");
        String outFile = in.nextLine();
        SimpleReader inputFile = new SimpleReader1L(inFile);
        /*
         * loops through input file grabing data
         */
        while (!inputFile.atEOS()) {
            /*
             * grabs line from input file
             */
            String temp = inputFile.nextLine();
            /*
             * if there is still words left then it loops through again
             */
            if (!temp.equals("")) {
                int position = 0;
                int spaceCount = 0;
                while (position < temp.length() && spaceCount == 0) {
                    //gets next word/separator
                    String token = nextWordOrSeparator(temp, position,
                            separatorSet);
                    if (separatorSet.contains(token.charAt(0))) {
                        //if it's a seperator of some kind
                        if (token.charAt(0) == ' ') {
                            spaceCount++;
                        }
                    }
                    position += token.length();
                }
                /*
                 * sorts whether it is a definition or a term based on the
                 * number of spaces (0 spaces = term)
                 */
                if (spaceCount == 0) {
                    terms.enqueue(temp);
                } else {
                    //encodes the term with the definition
                    terms.flip();
                    String tempTerm = terms.dequeue();
                    terms.flip();
                    //adds to map if there isn't a key already named for the term
                    if (!termsAndDef.hasKey(tempTerm)) {
                        termsAndDef.add(tempTerm, temp);
                    }
                    //concats the definitions if the map entry already exists
                    else {
                        String concat = termsAndDef.value(tempTerm) + " "
                                + temp;
                        termsAndDef.remove(tempTerm);
                        termsAndDef.add(tempTerm, concat);
                    }
                    //restores terms
                    terms.enqueue(tempTerm);
                }
            }
        }
        //sorts terms in alphabetical order
        terms.sort(order);
        //outputs all elements for index.html and all of the terms html files
        outputElements(outFile, separatorSet, termsAndDef, terms);
        /*
         * Close input and output streams
         */
        inputFile.close();
        in.close();
        out.close();
    }
}