/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
     */

/* gets a number input from user */ 
int getNum();

/* gets a string input from user */
void getString(char*);

/* prints book titles with numbers on the side to console */
void printBooks(char**, int);

/* prints favorite books with numbers on the side to console */
void printFavorites(char**, int);

/* creates/allocates memory for the book titles array and creates strings of titles based on user input */
char** populateArray(int);

/* creates/allocates memory for the favorites array based on user input */
char*** populateFavorites(char**, int);

/* writes titles and favorites chosen to file then frees memory used*/ 
void printToFile(char**, char***, int, int);

/* frees memory that was allocated previously for the pointer arrays */ 
void freeMemory(char***, char**, int, int);
