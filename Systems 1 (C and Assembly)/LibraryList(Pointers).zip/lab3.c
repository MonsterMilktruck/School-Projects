/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/

#include <stdlib.h>
#include <stdio.h>

/* gets a number input from user */ 
int getNum()
{
  int x;
  scanf("%d", &x);
  getchar(); /* skips the next character (be it new line, space, etc.) so the reader doesn't read it as input */
  return x;
}

/* gets a string input from user */ 
void getString(char* tempPtr)
{
  char currentCharacter;
  register r = 0;
  /* uses pointer arithmetic to designate characters in char array */ 
  while((currentCharacter = getchar()) != '\n')
  {
	*(tempPtr + r) = currentCharacter;
	r++;
  }
}

/* prints book titles with numbers on the side to console */
void printBooks(char** array, int numBooks)
{
  register int i;
  printf("\nYour books entered are:\n");
  for(i = 0; i < numBooks; i++)
  {
	printf("%i. %s\n", (i + 1), *(array + i));
  }
   printf("\n");
}

/* prints favorite books with numbers on the side to console */ 
void printFavorites(char*** favs, int numFavs)
{
  register int i;
  printf("\nYour favorites are:\n");
  for(i = 0; i < numFavs; i++)
  {
 	 printf("%i. %s\n", (i + 1), **(favs + i));
  }
  printf("\n");
}

/* creates/allocates memory for the book titles array and creates strings of titles based on user input */ 
char** populateArray(int numBooks)
{
  register int i, r;
  char currentCharacter;
  char **titles = (char**) malloc(numBooks * sizeof(char*));
  printf("Enter the %i book(s) title's, one per line: ", numBooks);
  /* gets user input and allocates space for each book title, then adds to array of titles */ 
  for(i = 0; i < numBooks; i++)
  {
    	char *tempPtr = (char*) malloc(61 * sizeof(char));
    	getString(tempPtr);
    	*(titles + i) = tempPtr;
  }
  return titles;
}

/* creates/allocates memory for the favorites array based on user input */ 
char*** populateFavorites(char** titles, int numFavorites)
{
 register int i;
 int currentTitle;
 char ***favorites = (char***) malloc(numFavorites * sizeof(char**));
 printf("Enter the %i book(s) number associated with ", numFavorites);
 printf("the title (use a separator after the number): ");
 /* gets user input for title number then fills char array */ 
 for(i = 0; i < numFavorites; i++)
  {
  	currentTitle = getNum();
	*(favorites + i) = titles + (currentTitle - 1);
  }
  return favorites;
}

/* writes titles and favorites chosen to file then frees memory used*/ 
void printToFile(char** books, char*** favs, int numBooks, int numFavs)
{
  register int i, r;
  FILE *out;
  /* allocates storage for fileName as it is a string */ 
  char *fileName = (char*) malloc (61 * sizeof(char));
  char currentCharacter;
  printf("What file name would you like to use? ");
  getString(fileName);
  /* opens file and overwrites it first so the file is empty */ 
  out = fopen(fileName,"w");    
  fputs("Books I've read:\n",out);
  fclose(out);
  fopen(fileName,"a");
  /* writes the book titles to file */ 
  for(i = 0; i < numBooks; i++)
  {
    	fputs(*(books + i),out);
    	fputs("\n", out); 
  }
  fputs("\nMy Favorites are:\n",out);
  /* writes the favorites list to file */ 
  for(i = 0; i < numFavs; i++)
  {
   	fputs(**(favs + i),out);
   	fputs("\n", out); 
  }
  fclose(out);
  printf("Your booklist and favorites were saved to %s\n", fileName);
  free(fileName);
  fileName = NULL;
}

/* frees memory that was allocated previously for the pointer arrays */ 
void freeMemory(char*** favs, char** books, int numBooks, int numFavs)
{
  register int i;
  for(i = 0; i < numBooks; i++)
  {
    if(*(books + i) != NULL)
    {
     	free(*(books + i));
     	 *(books + i) = NULL;
    }
  }
  free(books);
  books = NULL;
  free(favs);  
  favs = NULL;
  printf("Memory freed successfully");
}

int main(){
  int numBooks, numFavorites;
  char **books;
  char ***favorites;
  printf("Enter the number of books you plan to enter: ");
  numBooks = getNum();

  books = populateArray(numBooks);
  printBooks(books, numBooks);

  printf("Out of the %i books you entered,", numBooks);
  printf(" how many do you want to put on your favorite's list? ");
  numFavorites = getNum();

  favorites = populateFavorites(books, numFavorites);
  printFavorites(favorites, numFavorites);

  printf("Do you want to save your books/favorites to a file (1 = yes, 2 = no): ");
  if(getNum() == 1)
  {
    	printToFile(books, favorites, numBooks, numFavorites);
  }

 freeMemory(favorites, books, numBooks, numFavorites);
 return 0;
}

