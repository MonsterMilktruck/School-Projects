/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* function creates a node for the linked list from data */

#include "lab4.h"
Node* createNode(FILE* filePtr, char* studentName, Node* head)
{
  Node *nodePtr = (Node*) malloc(sizeof(struct Node)); 
  if(nodePtr == NULL)
  {
    printf("storage was not allocated for node");
    return nodePtr;
  }
  else
  {
    populateNode(filePtr, studentName, nodePtr, head); 
  }
  return nodePtr;
}
