/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* outputs to file specified */

#include "lab4.h"

void outputToFile(Node* list, char* outFileName, char* categories[])
{
  Node* traversePtr;
  int i;
  FILE *out, *outTemp;
/* opens then closes it in order to overwrite the file first */
  outTemp = fopen(outFileName, "w");
  traversePtr = list;
  fputs("", outTemp);
  fclose(outTemp);
  out = fopen(outFileName, "a");
/* outputs categories to file */
  for(i = 0; i < 4; i++)
    {
      fputs(categories[i], out);
      if(i != 3)
      {
        fputs(" ", out);
      }
    }
  fputs("\n", out);
/* outputs each Node to file */
  while(traversePtr != NULL)
    {
      fputs(traversePtr->Student.student_name, out);
      fputs("\n", out);
      fprintf(out, "%d\n", traversePtr->Student.student_ID);
      
      fprintf(out, "%.2f\t", traversePtr->Student.Cat1.score1);
      fprintf(out, "%.2f\t", traversePtr->Student.Cat1.score2);
      fprintf(out, "%.2f", traversePtr->Student.Cat1.score3);
      fputs("\n", out);
      fprintf(out, "%.2f\t", traversePtr->Student.Cat2.score1);
      fprintf(out, "%.2f\t", traversePtr->Student.Cat2.score2);
      fprintf(out, "%.2f", traversePtr->Student.Cat2.score3);
      fputs("\n", out);
      fprintf(out, "%.2f\t", traversePtr->Student.Cat3.score1);
      fprintf(out, "%.2f\t", traversePtr->Student.Cat3.score2);
      fprintf(out, "%.2f", traversePtr->Student.Cat3.score3);
      fputs("\n", out);
      fprintf(out, "%.2f\t", traversePtr->Student.Cat4.score1);
      fprintf(out, "%.2f\t", traversePtr->Student.Cat4.score2);
      fprintf(out, "%.2f", traversePtr->Student.Cat4.score3);
      fputs("\n", out);
      traversePtr = traversePtr ->next;
    }
  fclose(out);
}
