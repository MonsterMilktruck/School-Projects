/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* populates node with variables */
#include "lab4.h"
void populateNode(FILE* filePtr, char* studentName, Node* nodePtr, Node* head)
{
  /* first scans input, then calculates cumulative */
  
  strcpy(nodePtr->Student.student_name, studentName);
  nodePtr->Student.Final_Grade = -1.0;
  fscanf(filePtr, "%d", &nodePtr->Student.student_ID);
  if(isDuplicate(head, nodePtr->Student.student_ID))
  {
    free(nodePtr);
    printf("Student was already in the Database!");
    return;
  }
  fscanf(filePtr, "%f", &nodePtr->Student.Cat1.score1);
  fscanf(filePtr, "%f", &nodePtr->Student.Cat1.score2);
  fscanf(filePtr, "%f", &nodePtr->Student.Cat1.score3);

  nodePtr->Student.Cat1.Cumulative = calculateCumulative(nodePtr, 1);
  
  fscanf(filePtr, "%f", &nodePtr->Student.Cat2.score1);
  fscanf(filePtr, "%f", &nodePtr->Student.Cat2.score2);
  fscanf(filePtr, "%f", &nodePtr->Student.Cat2.score3);

  nodePtr->Student.Cat2.Cumulative = calculateCumulative(nodePtr, 2);
  
  fscanf(filePtr, "%f", &nodePtr->Student.Cat3.score1);
  fscanf(filePtr, "%f", &nodePtr->Student.Cat3.score2);
  fscanf(filePtr, "%f", &nodePtr->Student.Cat3.score3);

  nodePtr->Student.Cat3.Cumulative = calculateCumulative(nodePtr, 3);
  
  fscanf(filePtr, "%f", &nodePtr->Student.Cat4.score1);
  fscanf(filePtr, "%f", &nodePtr->Student.Cat4.score2);
  fscanf(filePtr, "%f", &nodePtr->Student.Cat4.score3);

  nodePtr->Student.Cat4.Cumulative = calculateCumulative(nodePtr, 4);

  
  /* so it doesnt read \n as the next line */
  fgetc(filePtr);

  /* calculates current grade */

  nodePtr->Student.Current_Grade = calcCurrentGrade(nodePtr);
}
