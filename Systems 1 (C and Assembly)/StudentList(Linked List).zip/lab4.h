/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct Cat_Grade{
  float score1;
  float score2;
  float score3;
  float Cumulative;
};

struct Data {
  char student_name[40]; 
  int student_ID;
  struct Cat_Grade Cat1;
  struct Cat_Grade Cat2;
  struct Cat_Grade Cat3;
  struct Cat_Grade Cat4;
  float Current_Grade; 
  float Final_Grade;
};

typedef struct Node { 
  struct Data Student; 
  struct Node *next;
} Node;

void printHeader(char* Category_Names[]);

void printLine(Node *head, char *Category_Names[]);

int isDuplicate(Node *head, int newStudentID);

Node* createNode(FILE* filePtr, char* studentName, Node* head);

Node* makeList(FILE* inFilePtr);

void populateNode(FILE* filePtr, char studentName[40], Node* nodePtr, Node* head);

Node* insertNode(Node* list_head, Node* node);

Node* get_NodeforID(Node* list_head, int stdtID);

void printStudent(Node* nodePtr);

void printStudentList(Node* list, char* categories[]);

int getSize(Node* list);

void determineOption(Node* list, char* cats[], char* outFileName);

Node* getNodeFromName(Node* list, char* lastName, int size);

void printFromLastName(Node *head, char *Category_Names[]);

float calculateCumulative(Node* nodePtr, int catNum);

float calcCurrentGrade(Node* nodePtr);

void recalcGrade(Node* list, char* categories[]);

void recalcAllGrades(Node* list, char* categories[]);

void storeNewScore(Node* head, char* categories[]);

void calcFinalGrade(Node* head, char* categories[]);

Node* addStudent(Node* list, char* categories[]);

Node* deleteStudent(Node* list);

Node* removeTop(Node* list);

Node* removeNode(Node* list, Node* node);

Node* freeMemory(Node* list, char* categories[]);

void outputToFile(Node* list, char* outFileName, char* categories[]);
