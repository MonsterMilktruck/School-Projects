/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* prompts for and uses a function pointer to execute options by the User */

#include "lab4.h"

void determineOption(Node* list, char* cats[], char* outFileName)
{
  int choice, isDone = 0;
  void (*functions[7])(Node* head, char* categories[]);
  functions[0] = printLine;
  functions[1] = printFromLastName;
  functions[2] = printStudentList;
  functions[3] = recalcGrade;
  functions[4] = recalcAllGrades;
  functions[5] = storeNewScore;
  functions[6] = calcFinalGrade;
/* Repeatedly asks user for option until valid on is given. Then uses a function pointer to call a fuction */
  do{
    printf("Enter an option between 1 and 10:\n1)  Print Student Scores by Student ID\n2)  Print Student Scores by Last Name\n3)  Print Student Scores for All Students\n4)  Recalculate Student Scores for a Single Student ID\n5)  Recalculate All Student Scores\n6)  Insert a score for a specific Student ID\n7)  Calculate Final Grades\n8)  Add a new student\n9)  Delete a student\n10) Exit Program\n\nOption: ");
  scanf("%d",&choice);
  switch(choice)
    {
    case 1:
    {
      functions[0](list, cats);
      break;
    }
    case 2:
    {
      functions[1](list, cats);
      break;
    }
    case 3:
    {
      functions[2](list, cats);
      break;
    }
    case 4:
    {
      functions[3](list, cats);
      break;
    }
    case 5:
    {
       functions[4](list, cats);
      break;
    }
    case 6:
    {
      functions[5](list, cats);
      break;
    }
    case 7:
    {
      functions[6](list, cats);
      functions[2](list, cats);
      break;
    }
    case 8:
    {
      list = addStudent(list, cats);
      break;
    }
    case 9:
    {
      list = deleteStudent(list);
      break;
    }
    case 10:
    {
      isDone = 1;
      outputToFile(list, outFileName,cats);
      printf("outputting to %s\n", outFileName);
      list = freeMemory(list, cats);
      list = NULL;
      printf("memory freed successfully");
      break;
    }
    default:
      {
        printf("choose a valid option!\n");
      }
   }
    }while(!isDone);
  
    
}
