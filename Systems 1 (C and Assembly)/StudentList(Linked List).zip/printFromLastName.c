/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* This is the program for option 2
 * print student score for specific last name
 */
#include "lab4.h"
void printFromLastName(Node *head, char *Category_Names[])
{
  Node *NodePtr;
  char lastName[40];
  #ifdef DEBUG
  printf("Student Data. Head List is %x\n", head);
  #endif
  /* get Last Name to use from user */
  printf("Enter the Last Name: ");
  scanf("%s", lastName);
  printf("Hunting for %s\n", lastName);
  /* look for the correct student Node */
  NodePtr = getNodeFromName(head, lastName, getSize(head));
  /* we found it or not */
  if(NodePtr == NULL){
    printf("\nERROR: last name %s was not found in the list\n",lastName);
  }
  else {
    printHeader(Category_Names);
    printStudent(NodePtr);
  }
}
