/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* option 5 - recalculates all grades for all students */
#include "lab4.h"
void recalcAllGrades(Node* list, char* categories[])
{
  Node* traversePtr = list;
  while(traversePtr != NULL)
  {
/* calculates cumulatives and current grade */
    traversePtr->Student.Cat1.Cumulative = calculateCumulative(traversePtr, 1);
    traversePtr->Student.Cat2.Cumulative = calculateCumulative(traversePtr, 2);
    traversePtr->Student.Cat3.Cumulative = calculateCumulative(traversePtr, 3);
    traversePtr->Student.Cat4.Cumulative = calculateCumulative(traversePtr, 4);
    traversePtr->Student.Current_Grade = calcCurrentGrade(traversePtr);
   traversePtr->Student.Final_Grade = -1;
/* prints to console the data */
    printf("Student Name: %-22s\t", traversePtr->Student.student_name);
    printf("%s Cumulative: %-5.2f\t", categories[0], traversePtr->Student.Cat1.Cumulative);
    printf("%s Cumulative: %-5.2f\t", categories[1], traversePtr->Student.Cat2.Cumulative);
    printf("%s Cumulative: %-5.2f\t", categories[2], traversePtr->Student.Cat3.Cumulative);
    printf("%s Cumulative: %-5.2f", categories[3], traversePtr->Student.Cat4.Cumulative);
    printf("\tCurrent Grade: %-5.2f\n", traversePtr->Student.Current_Grade);
/* repeats for next student */
    traversePtr = traversePtr->next;
  }
}
