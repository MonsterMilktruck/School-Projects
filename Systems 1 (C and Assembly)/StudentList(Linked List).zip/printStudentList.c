/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* option 3 - prints out full student list with header in order of Student ID*/

#include "lab4.h"

void printStudentList(Node* list, char* categories[])
{
  Node* traversePtr = list;
  printHeader(categories);
/* traverses list printing out the students */
  while(traversePtr != NULL)
    {
      printStudent(traversePtr);
      traversePtr = traversePtr->next;
    }
  printf("\n");
}
