/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* prompts for data and adds student to list */

#include "lab4.h"

Node* addStudent(Node* list, char* categories[])
{
  char studentName[40];
  int stdID, isDone, i;
  char c;
  
  Node* newStudent = malloc(sizeof(struct Node));
  printf("Enter the Student's Name: ");
  i = 0;
  while(((c = getchar()) != '\n') && i < 40)
    {
      studentName[i] = c;
      i++;
    }
  scanf("%99[^\n]", studentName);
  strcpy(newStudent->Student.student_name ,studentName);
  
  isDone = 1;
  do
  {
    isDone = 1;
    printf("Enter the Student's ID: ");
    scanf("%d", &stdID);
    if(isDuplicate(list, stdID))
    {
      printf("Student was already in the Database!");
      isDone = 0;
    }
  }while(!isDone);
  newStudent->Student.student_ID = stdID;
  printf("Enter the first %s score: ", categories[0]);
  scanf("%f", &newStudent->Student.Cat1.score1);
  printf("Enter the second %s score: ", categories[0]);
  scanf("%f", &newStudent->Student.Cat1.score2);
  printf("Enter the third %s score: ", categories[0]);
  scanf("%f", &newStudent->Student.Cat1.score3);
  printf("Enter the first %s score: ", categories[1]);
  scanf("%f", &newStudent->Student.Cat2.score1);
  printf("Enter the second %s score: ", categories[1]);
  scanf("%f", &newStudent->Student.Cat2.score2);
  printf("Enter the third %s score: ", categories[1]);
  scanf("%f", &newStudent->Student.Cat2.score3);
  printf("Enter the first %s score: ", categories[2]);
  scanf("%f", &newStudent->Student.Cat3.score1);
  printf("Enter the second %s score: ", categories[2]);
  scanf("%f", &newStudent->Student.Cat3.score2);
  printf("Enter the third %s score: ", categories[2]);
  scanf("%f", &newStudent->Student.Cat3.score3);
  printf("Enter the first %s score: ", categories[3]);
  scanf("%f", &newStudent->Student.Cat4.score1);
  printf("Enter the second %s score: ", categories[3]);
  scanf("%f", &newStudent->Student.Cat4.score2);
  printf("Enter the third %s score: ", categories[3]);
  scanf("%f", &newStudent->Student.Cat4.score3);
  newStudent->Student.Cat1.Cumulative = calculateCumulative(newStudent, 1);
  newStudent->Student.Cat2.Cumulative = calculateCumulative(newStudent, 2);
  newStudent->Student.Cat3.Cumulative = calculateCumulative(newStudent, 3);
  newStudent->Student.Cat4.Cumulative = calculateCumulative(newStudent, 4);
  newStudent->Student.Current_Grade = calcCurrentGrade(newStudent);

   newStudent->Student.Final_Grade = -1;
  list = insertNode(list, newStudent);
  
  printf("%s, Student ID #%d has been added with the following information:\n", newStudent->Student.student_name, newStudent->Student.student_ID);
  printHeader(categories);
  printStudent(newStudent);
  return list;
}
