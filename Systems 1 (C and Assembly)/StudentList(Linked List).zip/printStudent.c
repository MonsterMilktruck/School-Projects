/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* prints out a student's credentials */
#include "lab4.h"
void printStudent(Node* nodePtr)
{
  printf("%-22s", nodePtr->Student.student_name);
  printf("\t%-5d", nodePtr->Student.student_ID);
  /* prints scores */
  if(nodePtr->Student.Cat1.score1 == -1)
  {
   printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat1.score1);
  }
  if(nodePtr->Student.Cat1.score2 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat1.score2);
  }
  if(nodePtr->Student.Cat1.score3 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat1.score3);
  }
  if(nodePtr->Student.Cat1.Cumulative == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat1.Cumulative);
  }

  if(nodePtr->Student.Cat2.score1 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat2.score1);
  }
  if(nodePtr->Student.Cat2.score2 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat2.score2);
  }
  if(nodePtr->Student.Cat2.score3 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat2.score3);
  }
  if(nodePtr->Student.Cat2.Cumulative == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat2.Cumulative);
  }

  if(nodePtr->Student.Cat3.score1 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat3.score1);
  }
  if(nodePtr->Student.Cat3.score2 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat3.score2);
  }
  if(nodePtr->Student.Cat3.score3 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat3.score3);
  }
  if(nodePtr->Student.Cat3.Cumulative == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat3.Cumulative);
  }

  if(nodePtr->Student.Cat4.score1 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat4.score1);
  }
  if(nodePtr->Student.Cat4.score2 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat4.score2);
  }
  if(nodePtr->Student.Cat4.score3 == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat4.score3);
  }
  if(nodePtr->Student.Cat4.Cumulative == -1)
  {
    printf("\tn/a  ");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Cat4.Cumulative);
  }
  if(nodePtr->Student.Current_Grade == -1)
  {
    printf("\tn/a");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Current_Grade);
  }
  if(nodePtr->Student.Final_Grade == -1)
  {
    printf("\tn/a");
  }
  else
  {
     printf("\t%5.2f", nodePtr->Student.Final_Grade);
  }
  printf("\n");
}
