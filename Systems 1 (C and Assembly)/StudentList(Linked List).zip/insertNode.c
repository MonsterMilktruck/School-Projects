/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* Inserts Node based on Student_ID */
#include "lab4.h"
Node* insertNode(Node* list_head, Node* node)
{
  int isDone = 0;
  Node* traversePtr = list_head;
  
  /* checks if node is supposed to be in front */
  if(node->Student.student_ID < traversePtr->Student.student_ID)
  {
    node->next = list_head;
    list_head = node;
  }
    /* if it doesn't then checks the whole list until it finds something */
  else
  {
    while(!isDone && (traversePtr->next != NULL))
      {
        /* checks if the next node's ID is greater than the inserted node */
        if(node->Student.student_ID < traversePtr->next->Student.student_ID)
        {
          isDone = 1;
          node->next = traversePtr->next;
          traversePtr->next = node;
        }
        traversePtr = traversePtr->next;
      }
    /* if the ID is greater than all of them, then insert node at the end */
    if(!isDone)
    {
      traversePtr->next = node;
      node->next = NULL;
    }
  }
  return list_head;
}
