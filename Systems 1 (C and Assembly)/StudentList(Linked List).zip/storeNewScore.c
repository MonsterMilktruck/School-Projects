/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* option 6 - allows user to modify a students score from their student ID */

#include "lab4.h"

void storeNewScore(Node* head, char* categories[])
{
  Node *NodePtr;
  int StudentID, i, cat, scoreNum;
  float score;
  /* get studentID to use from user */
  printf("Enter the Student ID #: ");
  scanf("%i", &StudentID);
  printf("Hunting for %d\n", StudentID);
  /* look for the correct student Node */
  NodePtr = get_NodeforID(head, StudentID);
  if(NodePtr == NULL){
    printf("\nERROR: Student ID number %i was not found in the list\n",StudentID);
  }
  else
  {
/* prompts user for input on category and score number */
    printf("What category do you want to insert it in?\n");
    for(i = 0; i < 4; i++)
      {
        printf("%d) %s\n", (i+1), categories[i]);
      }
    scanf("%d", &cat);
    printf("What score number? (1, 2, or 3)\n");
    scanf("%d", &scoreNum);
    printf("New score: ");
    scanf("%f", &score);
/* uses a nested switch statement to know which specific category and score to change */
    switch(cat)
      {
        case 1:
          {
            switch(scoreNum)
              {
                case 1:
                  {
                    NodePtr->Student.Cat1.score1 = score;
                    break;
                  }
                case 2:
                  {
                    NodePtr->Student.Cat1.score2 = score;
                    break;
                  }
                case 3:
                  {
                    NodePtr->Student.Cat1.score3 = score;
                    break;
                  }
              }
            break;
          }
        case 2:
          {
            switch(scoreNum)
              {
                case 1:
                  {
                    NodePtr->Student.Cat2.score1 = score;
                    break;
                  }
                case 2:
                  {
                    NodePtr->Student.Cat2.score2 = score;
                    break;
                  }
                case 3:
                  {
                    NodePtr->Student.Cat2.score3 = score;
                    break;
                  }
              }
            break;
          }
        case 3:
          {
            switch(scoreNum)
              {
                case 1:
                  {
                    NodePtr->Student.Cat3.score1 = score;
                    break;
                  }
                case 2:
                  {
                    NodePtr->Student.Cat3.score2 = score;
                    break;
                  }
                case 3:
                  {
                    NodePtr->Student.Cat3.score3 = score;
                    break;
                  }
              }
            break;
          }
        case 4:
          {
            switch(scoreNum)
              {
                case 1:
                  {
                    NodePtr->Student.Cat4.score1 = score;
                    break;
                  }
                case 2:
                  {
                    NodePtr->Student.Cat4.score2 = score;
                    break;
                  }
                case 3:
                  {
                    NodePtr->Student.Cat4.score3 = score;
                    break;
                  }
              }
            break;
          }
      }
  }
  } 
