#include <stdio.h>
#include "lab4.h"

int main(int numArgs, char* arguments[]) {
  char* fileInput; 
  char* fileOutput;
  FILE *inFilePtr;
  int i, r;
  char c;
  char* categories[4];
  Node* student_list;
  /* takes in files from arguments */
  fileInput = arguments[1];
  fileOutput = arguments[2];
  printf("Reading student information from file \"%s\"\n", fileInput);
  inFilePtr = fopen(fileInput, "r");
  if(inFilePtr == NULL)
  {
    printf("error opening file");
  }
/* allocates memory/takes in categories */
  for(i = 0; i < 4; i++)
    {
      r = 0;
      categories[i] = malloc(30 * sizeof(char));
      while(((c = fgetc(inFilePtr)) != '\n') && c != ' ')
        {
          *(categories[i] + r) = c;
          r++;
        }
    }
  

  student_list = makeList(inFilePtr);
  fclose(inFilePtr);
  printf("%d student record(s) were read from the file \"%s\"\n", getSize(student_list), fileInput);
  determineOption(student_list, categories, fileOutput);
  }
