/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* deletes student */

#include "lab4.h"

Node* deleteStudent(Node* list)
{
  int stdID;
  Node* NodePtr;
  printf("Enter the Student ID for the student you wish to delete: ");
  scanf("%d", &stdID);
  NodePtr = get_NodeforID(list, stdID);
  /* we found it or not */
  if(NodePtr == NULL){
    printf("\nERROR: Student ID number %i was not found in the list\n",stdID);
    return;
  }
  else
  {
    printf("%s, Student ID #%d has been successfully deleted\n", NodePtr->Student.student_name, NodePtr->Student.student_ID);
    list = removeNode(list, NodePtr);
  }
  return list;
}
