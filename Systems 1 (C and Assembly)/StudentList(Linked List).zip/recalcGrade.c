/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* option 4 - recalculates a student's grade */

#include "lab4.h"

void recalcGrade(Node* list, char* categories[])
{
  int stdID;
  Node* student;
  printf("What is the Student ID for the scores you want to recalculate?\nStudent ID: ");
  scanf("%d", &stdID);
  student = get_NodeforID(list, stdID);
  printf("Recalculating grades for %s , Student ID number: %d\n", student->Student.student_name, stdID);
/* calculates cumulatives and current grade */
  student->Student.Cat1.Cumulative = calculateCumulative(student, 1);
  student->Student.Cat2.Cumulative = calculateCumulative(student, 2);
  student->Student.Cat3.Cumulative = calculateCumulative(student, 3);
 student->Student.Cat4.Cumulative = calculateCumulative(student, 4);
 student->Student.Current_Grade = calcCurrentGrade(student);
  student->Student.Final_Grade = -1;
/* outputs data to console */
  printf("%s Cumulative: %.2f\n", categories[0], student->Student.Cat1.Cumulative);
  printf("%s Cumulative: %.2f\n", categories[1], student->Student.Cat2.Cumulative);
  printf("%s Cumulative: %.2f\n", categories[2], student->Student.Cat3.Cumulative);
  printf("%s Cumulative: %.2f\n", categories[3], student->Student.Cat4.Cumulative);
  printf("Student's Final Grade was deleted\n\n");
}
