/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* gets a list of nodes from the name given */
#include "lab4.h"

Node* getNodeFromName(Node* list, char* lastName, int size)
{
  Node* listOfNames[100];
  int i, r,c;
  Node* traversePtr = list;
  i = 0;
  while(traversePtr != NULL)
    {
      if(strstr(traversePtr->Student.student_name, lastName) != NULL)
      {
        listOfNames[i] = traversePtr;
        i++;
      }
      traversePtr = traversePtr->next;
    }
  /* if there is more than 1 student located then prompt user to specify*/
  if(i > 1)
  {
    printf("There is more than one student by that name\n");
    r = 1;
    traversePtr = listOfNames[0];
    for(c = 1; c < i + 1; c++)
      {
        printf("%d) %s\n", c, listOfNames[c-1]->Student.student_name);
        r++;
      }
    printf("please select which number you want: ");
    scanf("%d", &i);
    traversePtr = listOfNames[i-1];
  }
  return traversePtr;
}
