/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* this method reads data from a file imputted and outputs a linked list*/

#include "lab4.h"

Node* makeList(FILE *inFilePtr)
{
  char studentName[40];
  Node *list_head;
  Node *tempNode;

  /* scans first student as 1 student is garenteed */
  
  fscanf(inFilePtr, "%[^\n]", studentName);
  tempNode = createNode(inFilePtr, studentName, list_head);
  list_head = tempNode;
  tempNode->next = NULL; 
  
  /* insert the rest of the students */
  while(fscanf(inFilePtr, "%[^\n]", studentName) != EOF)
    {
     tempNode = createNode(inFilePtr, studentName, list_head);
     list_head = insertNode(list_head, tempNode); 
    }
  return list_head;
}
