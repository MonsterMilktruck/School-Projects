/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* gets size of linked list */
#include "lab4.h"

int getSize(Node* list)
{
  int nodes = 0;
  Node* traversePtr = list;
  while(traversePtr != NULL)
    {
      nodes++;
      traversePtr = traversePtr->next;
    }
  return nodes;
}
