/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* frees memory for the entire list */

#include "lab4.h"

Node* freeMemory(Node* list, char* categories[])
{
  Node* tempPtr;
  int i;
/* frees memory in nodes then for the categories */
  while(list != NULL)
    {
      tempPtr = list;
      list = list->next;
      free(tempPtr);
      tempPtr = NULL;
    }
  for(i = 0; i < 4; i++)
    {
      free(categories[i]);
      categories[i] = NULL;
    }
  return list;
}
