/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* option 7 - calculates final grades for all students */

#include "lab4.h"

void calcFinalGrade(Node* head, char* categories[])
{
  Node* traversePtr = head;
  float s1, s2, s3, s4, result;
  while(traversePtr != NULL)
  {
    if(traversePtr->Student.Cat1.Cumulative == -1)
    {
      s1 = 0;
    }
    else
    {
      s1 = traversePtr->Student.Cat1.Cumulative;
    }
    if(traversePtr->Student.Cat2.Cumulative == -1)
    {
      s2 = 0;
    }
    else
    {
      s2 = traversePtr->Student.Cat2.Cumulative;
    }
    if(traversePtr->Student.Cat3.Cumulative == -1)
    {
      s3 = 0;
    }
    else
    {
      s3 = traversePtr->Student.Cat3.Cumulative;
    }
    if(traversePtr->Student.Cat4.Cumulative == -1)
    {
      s4 = 0;
    }
    else
    {
      s4 = traversePtr->Student.Cat4.Cumulative;
    }
    traversePtr->Student.Final_Grade = (s1 * .15) + (s2 * .3) + (s3 * .2) + (s4 * .35);
    traversePtr = traversePtr->next;
  }
}
