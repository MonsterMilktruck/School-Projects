/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* calculates cumulative grade from scores provided */

#include "lab4.h"

float calculateCumulative(Node* nodePtr, int catNum)
{
  float result, cumulative;
  float s1, s2, s3;
  s1 = 1.0;
  s2 = 1.0;
  s3 = 1.0;
  switch(catNum)
    {
      case 1:
        {
          if(nodePtr->Student.Cat1.score1 == -1)
          {
            s1 = 0;
          }
          if(nodePtr->Student.Cat1.score2 == -1)
          {
            s2 = 0;
          }
          if(nodePtr->Student.Cat1.score3 == -1)
          {
            s3 = 0;
          }
          /* if all scores are omitted then the cumulative is -1 else it calculates*/
          if(!(s1 || s2 || s3))
          {
            result = -1.00;
          }
          else
          {
            cumulative = (nodePtr->Student.Cat1.score1 * s1) + (nodePtr->Student.Cat1.score2 * s2) + (nodePtr->Student.Cat1.score3 * s3);
            result = cumulative/(s1 + s2 + s3);
          }
          break;
        }
      case 2:
        {
          if(nodePtr->Student.Cat2.score1 == -1)
          {
            s1 = 0;
          }
          if(nodePtr->Student.Cat2.score2 == -1)
          {
            s2 = 0;
          }
          if(nodePtr->Student.Cat2.score3 == -1)
          {
            s3 = 0;
          }
          /* if all scores are omitted then the cumulative is -1 else it calculates*/
          if(!(s1 || s2 || s3))
          {
            result = -1.00;
          }
          else
          {
            cumulative = (nodePtr->Student.Cat2.score1 * s1) + (nodePtr->Student.Cat2.score2 * s2) + (nodePtr->Student.Cat2.score3 * s3);
            result = cumulative/(s1 + s2 + s3);
          }
          break;
        }
      case 3:
        {
          if(nodePtr->Student.Cat3.score1 == -1)
          {
            s1 = 0;
          }
          if(nodePtr->Student.Cat3.score2 == -1)
          {
            s2 = 0;
          }
          if(nodePtr->Student.Cat3.score3 == -1)
          {
            s3 = 0;
          }
          /* if all scores are omitted then the cumulative is -1 else it calculates*/
          if(!(s1 || s2 || s3))
          {
            result = -1.00;
          }
          else
          {
            cumulative = (nodePtr->Student.Cat3.score1 * s1) + (nodePtr->Student.Cat3.score2 * s2) + (nodePtr->Student.Cat3.score3 * s3);
            result = cumulative/(s1 + s2 + s3);
          }
          break;
        }
      case 4:
        {
          if(nodePtr->Student.Cat4.score1 == -1)
          {
            s1 = 0;
          }
          if(nodePtr->Student.Cat4.score2 == -1)
          {
            s2 = 0;
          }
          if(nodePtr->Student.Cat4.score3 == -1)
          {
            s3 = 0;
          }
          /* if all scores are omitted then the cumulative is -1 else it calculates*/
          if(!(s1 || s2 || s3))
          {
            result = -1.00;
          }
          else
          {
            cumulative = (nodePtr->Student.Cat4.score1 * s1) + (nodePtr->Student.Cat4.score2 * s2) + (nodePtr->Student.Cat4.score3 * s3);
            result = cumulative/(s1 + s2 + s3);
          }
          break;
        }
    }
  return result;
}
