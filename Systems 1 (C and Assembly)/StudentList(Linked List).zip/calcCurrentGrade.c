/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* calculates current grade for student */
#include "lab4.h"

float calcCurrentGrade(Node* nodePtr)
{
  float s1, s2, s3, s4, result;
  if(nodePtr->Student.Cat1.Cumulative == -1)
  {
    s1 = 100.0;
  }
  else
  {
    s1 = nodePtr->Student.Cat1.Cumulative;
  }
  if(nodePtr->Student.Cat2.Cumulative == -1)
  {
    s2 = 100.0;
  }
  else
  {
    s2 = nodePtr->Student.Cat2.Cumulative;
  }
  if(nodePtr->Student.Cat3.Cumulative == -1)
  {
    s3 = 100.0;
  }
  else
  {
    s3 = nodePtr->Student.Cat3.Cumulative;
  }
  if(nodePtr->Student.Cat4.Cumulative == -1)
  {
    s4 = 100.0;
  }
  else
  {
    s4 = nodePtr->Student.Cat4.Cumulative;
  }
  result = (s1 * .15) + (s2 * .3) + (s3 * .2) + (s4 * .35);
  return result;

}
