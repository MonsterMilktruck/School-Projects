/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
/* gets a student node from the ID given */
#include "lab4.h"
Node* get_NodeforID(Node* list_head, int stdtID)
{
  int isDone = 0;
  Node* studentNode = list_head;
  while(!isDone && (studentNode != NULL))
    {
      if(stdtID == studentNode->Student.student_ID)
      {
        isDone = 1;
      }
      else
      {
        studentNode = studentNode->next;
      }
    }
  return studentNode;
}
