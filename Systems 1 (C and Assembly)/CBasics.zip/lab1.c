
	#include <stdio.h>
	/* Author: Brady Scott */ 
	/*BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE WORK TO
	CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN 		THE INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHEARED TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC 		INTEGRITY POLICY */

	int main(void)
	{
		unsigned int maxEntries;
		int getchar_return_value; 		/* note manual page says getchar() returns an integer value	*/
		char keyboard_value[25];		/* declare space to hold the keyboard values			*/
		int i;				/* declare i to track amount of times through loop		*/

		printf("This program reads in a number, then a series of keyboard characters. The number\n");
		printf("indicates how many characters follow. The number can be no higher than 25.\n");
		printf("Then the specified number of characters follows.  These characters can be any\n");
		printf("key on a regular keyboard.\n");

		/* Read the first number entered to know how many entries will follow		*/
		printf("Please enter the number of entries, followed by the enter/return key: ");
		scanf("%u", &maxEntries);		
		if (maxEntries > 25) {
			printf("Specified number of characters is invalid. It must be between 0 and 25.\n");
			return;
		}
		getchar();		/* trash the '\n'	*/
		printf("enter the %u characters: ", maxEntries);
		for(i = 0; i<maxEntries; i++)
		{
			getchar_return_value = getchar();
			if (getchar_return_value != EOF){
				keyboard_value[i] = (char)getchar_return_value;
			}
			else{
				printf("fewer than %u characters entered, number of characters set to %d\n",maxEntries,i);
				maxEntries = i;
				break;
			
			}
		}
		printf("the keyboard values are: \n");
		for(i = 0; i<maxEntries; i++)           /* print them out */
		{
			putchar(keyboard_value[i]);
			putchar('\n');
		}
	}
	
