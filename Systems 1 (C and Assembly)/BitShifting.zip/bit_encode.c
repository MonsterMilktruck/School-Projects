/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE 
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR 
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE 
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
     */




/*TING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE 
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR 
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE 
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
     */


#include <stdio.h>
#include <stdlib.h>
/* #define PROMPT */
/* Puts text typed into array of characters and outputs length of input*/
int convertTextToArray(unsigned char array[])
{
	int i = 0;
	unsigned char c;
	/* i = length and populates array */
	while((c = getchar()) != '\n')
	{
		array[i] = c;
		i++;
	}
	return i++;
}

/* Prints out text from array*/
void printArray(unsigned char array[], int length)
{
	int r;
	printf("\nText entered is: ");
	for(r = 0; r < length; r++)
	{
		printf("%c", array[r]);
	}
}

/* Prints hexidecimal encoding of the input array */
void printHex(unsigned char array[], int length)
{
	int r;
	/* prints only 10 values per line */
	for(r = 0; r < length; r++)
	{
		#ifdef PROMPT
			if(r % 10 == 0)
			{
				printf("\n");
			}
		#endif
		printf("%02X ", array[r]);
	}
	printf("\n");
}

/* Prompts user for key to encrypt and returns it */
unsigned char promptKey()
{
	int i = 3;
	unsigned char c, result;
	char key[8];
	#ifdef PROMPT
		printf("\nenter 4-bit key: ");
	#endif
	 /* takes in key from input */

	while((c = getchar()) != '\n')
	{
		key[i] = c;
		key[i + 4] = c;
		i--;
	}
  
	result = (unsigned char)strtol(key, 0, 2);
	return result;
}

/* exclusive or's the bits of the hexicimal number and the encrypts key */
void encrypt(unsigned char key, unsigned char text[], int length)
{
	int temp;
	/* uses ^ to XOR characters in array */
	for(temp = 0; temp < length; temp++)
	{
		text[temp] = text[temp] ^ key;
	}

}
/* encrypts words from a 4 bit key given by the user and outputs it to the console
	author: Brady Scott */
int main()
{
	int length;
	unsigned char encryptKey;
	unsigned char text[200];
	#ifdef PROMPT
		printf("enter cleartext: ");
	#endif
	length = convertTextToArray(text);
	#ifdef PROMPT
		printArray(text, length);
		printf("\n\n");
		printf("Hex encoding is:");
		printHex(text, length);
	#endif
	encryptKey = promptKey();
	encrypt(encryptKey, text, length);
	#ifdef PROMPT
		printf("hex ciphertext:");
	#endif
	printHex(text, length);
 
	return 0;
}



