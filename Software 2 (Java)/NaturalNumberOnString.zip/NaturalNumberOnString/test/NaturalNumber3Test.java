import components.naturalnumber.NaturalNumber;

/**
 * Customized JUnit test fixture for {@code NaturalNumber3}.
 */
public class NaturalNumber3Test extends NaturalNumberTest {

    @Override
    protected final NaturalNumber constructorTest() {

        NaturalNumber newNum = new NaturalNumber3();
        return newNum;
    }

    @Override
    protected final NaturalNumber constructorTest(int i) {

        NaturalNumber newNum = new NaturalNumber3(i);
        return newNum;
    }

    @Override
    protected final NaturalNumber constructorTest(String s) {

        NaturalNumber newNum = new NaturalNumber3(s);
        return newNum;
    }

    @Override
    protected final NaturalNumber constructorTest(NaturalNumber n) {

        NaturalNumber newNum = new NaturalNumber3(n);
        return newNum;
    }

    @Override
    protected final NaturalNumber constructorRef() {

        NaturalNumber newNum = new NaturalNumber3();
        return newNum;
    }

    @Override
    protected final NaturalNumber constructorRef(int i) {

        NaturalNumber newNum = new NaturalNumber3(i);
        return newNum;
    }

    @Override
    protected final NaturalNumber constructorRef(String s) {

        NaturalNumber newNum = new NaturalNumber3(s);
        return newNum;
    }

    @Override
    protected final NaturalNumber constructorRef(NaturalNumber n) {

        NaturalNumber newNum = new NaturalNumber3(n);
        return newNum;
    }

}
