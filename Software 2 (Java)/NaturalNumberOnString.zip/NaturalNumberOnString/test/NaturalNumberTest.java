import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Put your name here
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero

    @Test
    //Routine
    public void emptyConstructorTest1() {
        /*
         * Blank constructor test
         */
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Boundary
    public void integerConstructorTest1() {
        /*
         * Integer parameter constructor test
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Routine
    public void integerConstructorTest2() {
        /*
         * Integer parameter constructor test
         */
        NaturalNumber n = this.constructorTest(5);
        NaturalNumber nExpected = this.constructorRef(5);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Boundary
    public void integerConstructorTest3() {
        /*
         * Integer parameter constructor test
         */
        NaturalNumber n = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber nExpected = this.constructorRef(Integer.MAX_VALUE);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Boundary
    public void stringConstructorTest1() {
        /*
         * String parameter test
         */
        NaturalNumber n = this.constructorTest("0");
        NaturalNumber nExpected = this.constructorRef("0");

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Routine
    public void stringConstructorTest2() {
        /*
         * String parameter constructor test
         */
        NaturalNumber n = this.constructorTest("5");
        NaturalNumber nExpected = this.constructorRef("5");

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Challenge
    public void stringConstructorTest3() {
        /*
         * String parameter constructor test
         */
        NaturalNumber n = this.constructorTest("12345678901234567890");
        NaturalNumber nExpected = this.constructorRef("12345678901234567890");

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Boundary
    public void naturalNumConstructorTest1() {
        /*
         * Natural Number parameter constructor test
         */
        NaturalNumber temp = new NaturalNumber3();
        NaturalNumber tempExpected = new NaturalNumber3();

        NaturalNumber n = this.constructorTest(temp);
        NaturalNumber nExpected = this.constructorRef(tempExpected);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Routine
    public void naturalNumConstructorTest2() {
        /*
         * Natural Number parameter constructor test
         */
        NaturalNumber temp = new NaturalNumber3(5);
        NaturalNumber tempExpected = new NaturalNumber3(5);

        NaturalNumber n = this.constructorTest(temp);
        NaturalNumber nExpected = this.constructorRef(tempExpected);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Routine
    public void naturalNumConstructorTest3() {
        /*
         * Natural Number parameter constructor test
         */
        NaturalNumber temp = new NaturalNumber3("5");
        NaturalNumber tempExpected = new NaturalNumber3("5");

        NaturalNumber n = this.constructorTest(temp);
        NaturalNumber nExpected = this.constructorRef(tempExpected);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Challenge
    public void naturalNumConstructorTest4() {
        /*
         * Natural Number parameter constructor test
         */
        NaturalNumber temp = new NaturalNumber3("12345678901234567890");
        NaturalNumber tempExpected = new NaturalNumber3("12345678901234567890");

        NaturalNumber n = this.constructorTest(temp);
        NaturalNumber nExpected = this.constructorRef(tempExpected);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Routine
    public void multiplyByTenTest1() {
        /*
         * Natural Number multiplyBy10 kernel method test
         */
        NaturalNumber n = this.constructorTest(5);
        NaturalNumber nExpected = this.constructorRef(50);

        n.multiplyBy10(0);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Routine
    public void multiplyByTenTest2() {
        /*
         * Natural Number multiplyBy10 kernel method test
         */
        NaturalNumber n = this.constructorTest(5);
        NaturalNumber nExpected = this.constructorRef(55);

        n.multiplyBy10(5);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Boundary
    public void multiplyByTenTest3() {
        /*
         * Natural Number multiplyBy10 kernel method test
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);

        n.multiplyBy10(0);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Challenge
    public void multiplyByTenTest4() {
        /*
         * Natural Number multiplyBy10 kernel method test
         */
        NaturalNumber n = this.constructorTest("5040302010");
        NaturalNumber nExpected = this.constructorRef("50403020107");

        n.multiplyBy10(7);

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
    }

    @Test
    //Routine
    public void divideByTenTest1() {
        /*
         * Natural Number divideBy10 kernel method test
         */
        NaturalNumber n = this.constructorTest("50");
        NaturalNumber nExpected = this.constructorRef("5");

        int remainder = n.divideBy10();
        int expectedRemainder = 0;

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
        assertEquals(expectedRemainder, remainder);
    }

    @Test
    //Routine
    public void divideByTenTest2() {
        /*
         * Natural Number divideBy10 kernel method test
         */
        NaturalNumber n = this.constructorTest("4078");
        NaturalNumber nExpected = this.constructorRef("407");

        int remainder = n.divideBy10();
        int expectedRemainder = 8;

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
        assertEquals(expectedRemainder, remainder);
    }

    @Test
    //Boundary
    public void divideByTenTest3() {
        /*
         * Natural Number divideBy10 kernel method test
         */
        NaturalNumber n = this.constructorTest("5");
        NaturalNumber nExpected = this.constructorRef("0");

        int remainder = n.divideBy10();
        int expectedRemainder = 5;

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
        assertEquals(expectedRemainder, remainder);
    }

    @Test
    //Challenge
    public void divideByTenTest4() {
        /*
         * Natural Number divideBy10 kernel method test
         */
        NaturalNumber n = this.constructorTest("50403020107");
        NaturalNumber nExpected = this.constructorRef("5040302010");

        int remainder = n.divideBy10();
        int expectedRemainder = 7;

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
        assertEquals(expectedRemainder, remainder);
    }

    @Test
    //Routine
    public void isZeroTest1() {
        /*
         * Natural Number isZero kernel method test
         */
        NaturalNumber n = this.constructorTest("0");
        NaturalNumber nExpected = this.constructorRef("0");

        boolean nTest = n.isZero();

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
        assertTrue(nTest);
    }

    @Test
    //Routine
    public void isZeroTest2() {
        /*
         * Natural Number isZero kernel method test
         */
        NaturalNumber n = this.constructorTest("50");
        NaturalNumber nExpected = this.constructorRef("50");

        boolean nTest = n.isZero();

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
        assertFalse(nTest);
    }

    @Test
    //Challenge
    public void isZeroTest3() {
        /*
         * Natural Number isZero kernel method test
         */
        NaturalNumber n = this.constructorTest("908070605040302010");
        NaturalNumber nExpected = this.constructorRef("908070605040302010");

        boolean nTest = n.isZero();

        /*
         * Makes sure test meets expected value
         */
        assertEquals(nExpected, n);
        assertFalse(nTest);
    }
}
