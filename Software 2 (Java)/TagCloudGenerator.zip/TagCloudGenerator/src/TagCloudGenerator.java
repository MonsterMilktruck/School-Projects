import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine1L;
import components.utilities.Reporter;

/**
 * Tag Cloud Generator which displays number of desired words from a .txt file
 * to a .html file. Sizes words on html based on how many appearances each word
 * makes
 *
 * @author Kevin Haller & Brady Scott
 */
public final class TagCloudGenerator {

    /**
     * Private no-argument constructor.
     */
    private TagCloudGenerator() {

    }

    /**
     * Comparator that compares two keys lexicographically.
     *
     * @author Kevin Haller & Brady Scott
     *
     */
    private static class StringKeyLT
            implements Comparator<Map.Pair<String, Integer>> {

        @Override
        /**
         * Compares {@code pairOne} against {@code pairTwo} to check if
         * pairOne's key is lexicographically larger, less than, or equal to
         * pairTwo's key. Ignore case is used to avoid capital letters counting
         * as different words.
         *
         * @param pairOne
         *            The first Pair to use for comparison
         * @param pairTwo
         *            The second Pair to use for comparison
         * @return A value less than 0 if pairOne's key is less than pairTwo's
         *         key, 0 if pairOne's key and pairTwo's key are equal, or a
         *         value greater than 0 if pairOne's key is greater than
         *         pairTwo's key.
         */
        public int compare(Map.Pair<String, Integer> pairOne,
                Map.Pair<String, Integer> pairTwo) {
            return pairOne.key().compareToIgnoreCase(pairTwo.key());
        }
    }

    /**
     * Comparator that compares two values numerically.
     *
     * @author Kevin Haller & Brady Scott
     *
     */
    private static class IntegerValueGT
            implements Comparator<Map.Pair<String, Integer>> {

        @Override
        /**
         * Compares {@code pairOne} against {@code pairTwo} to check if
         * pairTwo's value is numerically larger, less than, or equal to
         * pairOne's value.
         *
         * @param pairOne
         *            The first Pair to use for comparison
         * @param pairTwo
         *            The second Pair to use for comparison
         * @return A value less than 0 if pairTwo's value is less than pairOne's
         *         value, 0 if pairOne's value and pairTwo's value are equal, or
         *         a value greater than 0 if pairTwo's value is greater than
         *         pairOne's value.
         */
        public int compare(Map.Pair<String, Integer> pairOne,
                Map.Pair<String, Integer> pairTwo) {
            return (Integer.compare(pairTwo.value(), pairOne.value()));
        }

    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param charSet
     *            the {@code Set} to be replaced
     * @replaces charSet
     * @ensures charSet = entries(str)
     */
    public static void generateElements(String str, Set<Character> charSet) {
        assert str != null : "Violation of: str is not null";
        assert charSet != null : "Violation of: charSet is not null";

        //Loops until each char in str is put into charSet
        for (int x = 0; x < str.length(); x++) {
            if (!charSet.contains(str.charAt(x))) {
                char c = str.charAt(x);
                charSet.add(c);
            }
        }

    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        String result = "";
        if (separators.contains(text.charAt(position))) {
            //Loops through substring of text
            //Keeps looping until loop runs into a letter
            for (int x = 0; x < text.substring(position, text.length())
                    .length(); x++) {
                char temp = text.charAt(position + x);
                if (separators.contains(temp)) {
                    result += temp;
                } else {
                    x = text.substring(position, text.length()).length();
                }
            }
        } else {
            //Loops through substring of text
            //Keeps looping until loop runs into a separator
            for (int x = 0; x < text.substring(position, text.length())
                    .length(); x++) {
                char temp = text.charAt(position + x);
                if (!separators.contains(temp)) {
                    result += temp;
                } else {
                    x = text.substring(position, text.length()).length();
                }
            }
        }
        return result;
    }

    /**
     * Creation of map by reading lines from {@code inFile}. Load terms as keys
     * and increments its associated value whenever a duplicate key appears.
     *
     * @param wordCount
     *            Empty map to be filled by words and values
     * @param inFile
     *            File reader containing terms and definitions to read from
     *
     * @ensures wordCounter is filled with every term and its associated count
     *          from inFile
     */
    public static void createMap(Map<String, Integer> wordCount,
            SimpleReader inFile) {

        //Creation of set containing separators
        Set<Character> separatorSet = new Set1L<>();
        String separatorStr = " \t\n\r,-.!?[]';:/()\"`";
        generateElements(separatorStr, separatorSet);

        String token = "";

        //Continue to read file until reader reaches the end
        while (!(inFile.atEOS())) {
            //Read one line to read from
            String line = inFile.nextLine();

            //Loops through the entire line
            for (int x = 0; x < line.length(); x += token.length()) {
                //Grabs the next word or separator at a given position
                token = nextWordOrSeparator(line, x, separatorSet);
                token = token.toLowerCase();
                //Checks whether token is a String of letters or separators
                char tokenVerify = token.charAt(0);
                if (!separatorSet.contains(tokenVerify)) {
                    //If key already exists, add 1 to the count
                    //If not, create new key with value 1.
                    if (wordCount.hasKey(token)) {
                        int currentCount = wordCount.value(token) + 1;
                        wordCount.replaceValue(token, currentCount);
                    } else {
                        wordCount.add(token, 1);
                    }
                }
            }
        }

    }

    /**
     *
     * @param out
     *            .html page to be written to
     * @param inFileName
     *            Name of user desired .txt file
     * @param num
     *            Number of desired words from user
     * @param sorter
     *            Sorting machine containing all words within users desired
     *            number in alphabetical order
     * @param highest
     *            The highest number of instances a word has within
     *            {@code sorter}
     * @param lowest
     *            The lowest number of instances a word has within
     *            {@code sorter}
     *
     * @ensures Outputs all desired data onto desired .html page
     *
     */
    public static void outputHtml(SimpleWriter out, String inFileName, int num,
            SortingMachine<Map.Pair<String, Integer>> sorter, int highest,
            int lowest) {

        //Print opening tags
        out.println("<html>");

        out.println("<head>");
        out.println(
                "<title>Top " + num + " word(s) in " + inFileName + "</title>");

        //Import css
        out.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println(
                "<link href=\"tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");

        //Print body
        out.println("<body>");
        out.println("<h2>Top " + num + " word(s) in " + inFileName + "</h2>");
        out.println("<hr>");
        out.println("<div class=\"cdiv\">");
        out.println("<p class=\"cbox\">");

        int range = highest - lowest;

        //Outputs each word with its appropriate size ratio along with its count in
        //alphabetical order
        for (int x = 0; x < num; x++) {
            //Removes pairs already in alphabetical order
            Map.Pair<String, Integer> temp = sorter.removeFirst();
            String key = temp.key();
            int value = temp.value();

            //Determine sizing of word for css convention
            int result = (int) ((((double) (value - lowest)) / range) * 37)
                    + 11;

            //Print result
            out.println("<span style=\"cursor:default\" class=\"f" + result
                    + "\" title=\"count: " + value + "\">" + key + "</span>");
        }

        //Closing tags
        out.println("</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");

    }

    /**
     * Given a file name containing terms, create a .html page that contains
     * every term and an accompanying value within a desired user size. Words
     * are also printed in different sizes depending on how many occurrences.
     *
     * @param args
     *            Command-line arguments: not used
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //User enters desired .txt file, error if not .txt
        out.println(
                "Enter the file name containing the desired text to be counted.");
        String fileName = in.nextLine();
        Reporter.assertElseFatalError(
                fileName.substring(fileName.length() - 4).equals(".txt"),
                "Fatal error, input file invalid input.  Expected .txt");
        SimpleReader inFile = new SimpleReader1L(fileName);

        //User enters desired .html file, error if not .html
        out.println("Enter the desired file name of the resulting html.");
        String outFileName = in.nextLine();
        Reporter.assertElseFatalError(
                outFileName.substring(outFileName.length() - 5).equals(".html"),
                "Fatal error, input file invalid input.  Expected .html");
        SimpleWriter outFile = new SimpleWriter1L(outFileName);

        //User enters desired number of words, error if not positive
        out.println("Enter the desired number of words in integer form.");
        String numWords = in.nextLine();
        int num = Integer.parseInt(numWords);
        Reporter.assertElseFatalError(num > 0,
                "Fatal error, desired number must be positive");

        //Creation and initialization of word, count map
        Map<String, Integer> wordCount = new Map1L<String, Integer>();
        createMap(wordCount, inFile);

        //Error if desired number of words exceeds number of words in map
        Reporter.assertElseFatalError(num <= wordCount.size(),
                "Fatal error, number of desired words exceeds number of words in text");

        //Creation of alphabetical sorting machine
        Comparator<Map.Pair<String, Integer>> alphOrder = new StringKeyLT();
        SortingMachine sorter = new SortingMachine1L<Map.Pair<String, Integer>>(
                alphOrder);

        //Creation of numerical sorting machine
        Comparator<Map.Pair<String, Integer>> intOrder = new IntegerValueGT();
        SortingMachine counter = new SortingMachine1L<Map.Pair<String, Integer>>(
                intOrder);

        //Add all words to numerical sorting machine and sort based off count
        for (Map.Pair<String, Integer> temp : wordCount) {
            counter.add(temp);
        }

        counter.changeToExtractionMode();

        //Note highest and lowest count of words and add the highest count words
        //to the sorting machine until it reaches users desired amount of words
        int highest = 0;
        int lowest = 0;

        for (int x = 0; x < num; x++) {
            Map.Pair<String, Integer> temp = (Map.Pair<String, Integer>) counter
                    .removeFirst();

            if (x == 0) {
                highest = temp.value();
            } else if (x == num - 1) {
                lowest = temp.value();
            }

            sorter.add(temp);
        }

        //Sort highest count words alphabetically
        sorter.changeToExtractionMode();

        //Output desired html
        outputHtml(outFile, fileName, num, sorter, highest, lowest);

        //Close I/O
        in.close();
        out.close();

    }
}
