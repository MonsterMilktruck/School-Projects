import java.util.Comparator;

import components.list.List;
import components.list.List1L;
import components.map.Map;
import components.map.Map2;
import components.queue.Queue;
import components.queue.Queue2;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * program to output word counts to a simple html page from an imported document
 *
 * @author Brady Scott
 */
public class WordCounter {

    /**
     * gets the next word from the text
     *
     * @param out
     *            file to write to
     * @return the first word or separator in the string of text
     * @requires out is a file to write to
     */
    public static void printHeading(SimpleWriter out) {
        out.print(
                "<html> <head> <title>Word Count</title></head> <body> <h2>Words Counted");
        out.print(
                "<hr /> <table border=\"1\"> <tr> <th>Words</th><th>Counts</th>");
        out.print("</tr>");
    }

    /**
     * gets the next word from the text
     *
     * @param text
     *            string which is pulled from a line of the input text
     * @param position
     *            the starting index
     * @param separators
     *            things to distinguish between words
     * @return the first word or separator in the string of text
     * @requires 0 <= position < |text|
     * @ensures the word returned is a word or a string of separators
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        String result = "";
        int count = 0;
        if (!separators.contains(text.charAt(position))) {
            for (int i = position + 1; i < text.length(); i++) {
                if (separators.contains(text.charAt(i)) && count == 0) {
                    result = text.substring(position, i);
                    count++;
                }
            }
            if (count == 0) {
                result = text.substring(position);
            }
        } else {
            for (int z = position + 1; z < text.length(); z++) {
                if (!separators.contains(text.charAt(z)) && count == 0) {
                    for (int r = position; r < z; r++) {
                        result = result + separators.remove(text.charAt(r));
                        separators.add(text.charAt(r));
                    }
                    count++;
                }
            }

            if (count == 0) {
                for (int r = position; r < text.length(); r++) {
                    result = result + separators.remove(text.charAt(r));
                    separators.add(text.charAt(r));
                }
            }
        }
        return result;

    }

    /**
     * gets the next word from the text
     *
     * @param temp
     *            string which is pulled from a line of the input text
     * @param separators
     *            things to distinguish between words
     * @return List of words gotten from the text
     */
    public static List findWords(String temp, Set<Character> separators) {
        List<String> words = new List1L<String>();
        int pos = 0;
        while (pos < temp.length()) {
            //gets next word/separator
            String token = nextWordOrSeparator(temp, pos, separators);
            pos += token.length();
            if (!(separators.contains(token.charAt(0)))) {
                words.addRightFront(token.toLowerCase());
            }

        }
        return words;

    }

    /**
     * gets the next word from the text
     *
     * @param in
     *            file to be read
     * @param separators
     *            things to distinguish between words
     * @return map of words and their number of occurrences
     * @requires in is a file that can be read
     */
    public static Map<String, Integer> readFileForWords(SimpleReader in,
            Set<Character> separators) {
        Map<String, Integer> termsAndNum = new Map2();
        String temp = in.nextLine();
        //stops when the end of the file is reached
        while (!in.atEOS()) {
            //finds words and puts them in a list
            List<String> tempSet = findWords(temp, separators);
            int initialSize = tempSet.rightLength();
            //removes words from list and adds it to the map/updates the number
            for (int i = 0; i < initialSize; i++) {
                String tempString = tempSet.removeRightFront();
                if (termsAndNum.hasKey(tempString)) {
                    termsAndNum.replaceValue(tempString,
                            termsAndNum.value(tempString) + 1);
                } else {
                    termsAndNum.add(tempString, 1);
                }
            }
            temp = in.nextLine();
        }
        return termsAndNum;

    }

    /**
     * prints words in the table for the html file
     *
     * @param in
     *            file to be read
     * @param out
     *            file to be printed too
     * @return map of words and their number of occurrences
     * @requires out is a file to write to and in is a file that can be read
     */
    public static void printWordRows(SimpleWriter out, SimpleReader in,
            Set<Character> separators, Queue<String> wordsInOrder,
            Comparator<String> order) {
        Map<String, Integer> mapToOutput = readFileForWords(in, separators);
        for (Map.Pair<String, Integer> words : mapToOutput) {
            wordsInOrder.enqueue(words.key());
        }
        wordsInOrder.sort(order);
        while (wordsInOrder.length() > 0) {
            String tempWord = wordsInOrder.dequeue();
            out.print("<tr><td>" + tempWord + "</td><td>"
                    + mapToOutput.value(tempWord) + "</td></tr>");
        }
        out.print("</table></body></html>");

    }

    /**
     * Compare {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.compareTo(o2);
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        final String separators = " \t,-.";
        SimpleWriter out = new SimpleWriter1L();
        SimpleReader in = new SimpleReader1L();
        Queue<String> words = new Queue2();
        Set<Character> separatorSet = new Set1L<>();
        for (int i = 0; i < separators.length(); i++) {
            separatorSet.add(separators.charAt(i));
        }
        Comparator<String> order = new StringLT();

        out.print("Input file: ");
        String fileToBeRead = in.nextLine();
        SimpleReader inFile = new SimpleReader1L(fileToBeRead);
        out.print("Output File: ");
        String fileToBeWritten = in.nextLine();
        SimpleWriter outFile = new SimpleWriter1L(fileToBeWritten);
        //prints heading to the html file
        printHeading(outFile);
        printWordRows(outFile, inFile, separatorSet, words, order);
        out.close();
        in.close();
        inFile.close();
        outFile.close();
    }

}
