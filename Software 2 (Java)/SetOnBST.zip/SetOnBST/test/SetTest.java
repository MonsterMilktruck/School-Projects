import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Put your name here
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    @Test
    //Routine
    public void constructorTest1() {
        Set<String> seq1 = this.createFromArgsTest("1");
        Set<String> seq2 = this.createFromArgsRef("1");

        assertEquals(seq2, seq1);
    }

    @Test
    //Boundary
    public void constructorTest2() {
        Set<String> seq1 = this.createFromArgsTest("");
        Set<String> seq2 = this.createFromArgsRef("");

        assertEquals(seq2, seq1);
    }

    @Test
    //Routine
    public void constructorTest3() {
        Set<String> seq1 = this.createFromArgsTest("1", "5", "10", "Yes");
        Set<String> seq2 = this.createFromArgsRef("1", "5", "10", "Yes");

        assertEquals(seq2, seq1);
    }

    @Test
    //Routine
    public void addTest1() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("1");
        Set<String> seq2 = this.createFromArgsRef("2", "1");

        /*
         * call method
         */
        seq1.add("2");

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(seq2, seq1);
    }

    @Test
    //Boundary
    public void addTest2() {
        Set<String> seq1 = this.createFromArgsTest();
        Set<String> seq2 = this.createFromArgsRef("1");

        seq1.add("1");

        assertEquals(seq2, seq1);
    }

    @Test
    //Routine
    public void addTest3() {
        Set<String> seq1 = this.createFromArgsTest("1");
        Set<String> seq2 = this.createFromArgsRef("1", "2", "3");

        seq1.add("2");
        seq1.add("3");

        assertEquals(seq2, seq1);
    }

    @Test
    //Routine (Characters)
    public void addTest4() {
        /*
         * Set up variables and call method under test
         */
        Set<String> q = this.createFromArgsTest("p", "o");
        Set<String> expectedq = this.createFromArgsRef("p", "o", "g");
        /*
         * call method
         */
        q.add("g");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
    }

    @Test
    //Boundary (Characters)
    public void addTest5() {
        /*
         * Set up variables and call method under test
         */
        Set<String> q = this.createFromArgsTest();
        Set<String> expectedq = this.createFromArgsRef("ok");
        /*
         * call method
         */
        q.add("ok");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
    }

    @Test
    //Routine
    public void removeTest1() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("1", "2", "3");
        Set<String> seq2 = this.createFromArgsRef("1", "3");

        /*
         * call method
         */
        String testString = seq1.remove("2");

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(seq2, seq1);
        assertEquals("2", testString);
    }

    @Test
    //Boundary
    public void removeTest2() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("1");
        Set<String> seq2 = this.createFromArgsRef();

        /*
         * call method
         */
        String testString = seq1.remove("1");

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(seq2, seq1);
        assertEquals("1", testString);
    }

    @Test
    //Routine (Characters)
    public void removeTest3() {
        /*
         * Set up variables and call method under test
         */
        Set<String> q = this.createFromArgsTest("ok", "man", "you");
        Set<String> expectedq = this.createFromArgsRef("ok", "you");
        /*
         * call method
         */
        q.remove("man");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
    }

    @Test
    //Boundary (Characters)
    public void removeTest4() {
        /*
         * Set up variables and call method under test
         */
        Set<String> q = this.createFromArgsTest("bruh");
        Set<String> expectedq = this.createFromArgsRef();

        /*
         * call method
         */
        String test = q.remove("bruh");
        String testRef = "bruh";
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(testRef, test);
        assertEquals(expectedq, q);
    }

    @Test
    //Routine
    public void removeAnyTest1() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("1", "2", "3");
        Set<String> seq2 = this.createFromArgsRef("2", "3");

        /*
         * call method Method should return smallest value in set
         */
        String testRef = seq1.removeAny();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(seq2, seq1);
        assertEquals("1", testRef);
    }

    @Test
    //Boundary
    public void removeAnyTest2() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("1");
        Set<String> seq2 = this.createFromArgsRef();

        /*
         * call method Method should return smallest value in set
         */
        String testRef = seq1.removeAny();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(seq2, seq1);
        assertEquals("1", testRef);

    }

    @Test
    //Challenge
    public void removeAnyTest3() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("7", "5", "1", "6", "8",
                "7.5");
        Set<String> seq2 = this.createFromArgsRef("7", "5", "6", "8", "7.5");

        /*
         * call method Method should return smallest value in set
         */
        String testRef = seq1.removeAny();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(seq2, seq1);
        assertEquals("1", testRef);
    }

    @Test
    //Routine (Characters)
    public void removeAnyTest4() {
        /*
         * Set up variables and call method under test
         */
        Set<String> q = this.createFromArgsTest("go", "bucks");
        Set<String> expectedq = this.createFromArgsRef("go");
        /*
         * Assert that values of variables match expectations
         */
        String testRef = q.removeAny();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
        assertEquals("bucks", testRef);
    }

    @Test
    //Routine
    public void containsTest1() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("1", "2", "3");
        Set<String> seq2 = this.createFromArgsRef("1", "2", "3");

        /*
         * call method
         */
        boolean result = seq1.contains("2");
        boolean expected = seq2.contains("2");

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expected, result);
    }

    @Test
    //Routine
    public void containsTest2() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("1", "2", "3");
        Set<String> seq2 = this.createFromArgsRef("1", "2", "3");

        /*
         * call method
         */
        boolean result = seq1.contains("4");
        boolean expected = seq2.contains("4");

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expected, result);
    }

    @Test
    //Routine
    public void sizeTest1() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest("1", "2", "3");
        Set<String> seq2 = this.createFromArgsRef("4", "5", "6");

        /*
         * call method
         */
        int size = seq1.size();
        int sizeExpected = seq2.size();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(sizeExpected, size);
    }

    @Test
    //Boundary
    public void sizeTest2() {
        /*
         * Set up variables and call method under test
         */
        Set<String> seq1 = this.createFromArgsTest();
        Set<String> seq2 = this.createFromArgsRef();

        /*
         * call method
         */
        int size = seq1.size();
        int sizeExpected = seq2.size();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(seq2, seq1);
        assertEquals(sizeExpected, size);
    }

    @Test
    //Routine (Characters)
    public void sizeTest3() {
        /*
         * Set up variables and call method under test
         */
        Set<String> q = this.createFromArgsTest("why", "man");
        Set<String> expectedq = this.createFromArgsRef("why", "man");

        int size = q.size();
        int sizeExpected = expectedq.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
        assertEquals(sizeExpected, size);
    }

}
