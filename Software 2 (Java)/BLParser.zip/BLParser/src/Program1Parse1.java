import components.map.Map;
import components.program.Program;
import components.program.Program1;
import components.queue.Queue;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.statement.Statement;
import components.statement.Statement1;
import components.utilities.Reporter;
import components.utilities.Tokenizer;

/**
 * Layered implementation of secondary method {@code parse} for {@code Program}.
 *
 * @author Brady Scott & Kevin Haller
 *
 */
public final class Program1Parse1 extends Program1 {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Parses a single BL instruction from {@code tokens} returning the
     * instruction name as the value of the function and the body of the
     * instruction in {@code body}.
     *
     * @param tokens
     *            the input tokens
     * @param body
     *            the instruction body
     * @return the instruction name
     * @replaces body
     * @updates tokens
     * @requires <pre>
     * [<"INSTRUCTION"> is a prefix of tokens]  and
     *  [<Tokenizer.END_OF_INPUT> is a suffix of tokens]
     * </pre>
     * @ensures <pre>
     * if [an instruction string is a proper prefix of #tokens]  and
     *    [the beginning name of this instruction equals its ending name]  and
     *    [the name of this instruction does not equal the name of a primitive
     *     instruction in the BL language] then
     *  parseInstruction = [name of instruction at start of #tokens]  and
     *  body = [Statement corresponding to the block string that is the body of
     *          the instruction string at start of #tokens]  and
     *  #tokens = [instruction string at start of #tokens] * tokens
     * else
     *  [report an appropriate error message to the console and terminate client]
     * </pre>
     */
    private static String parseInstruction(Queue<String> tokens,
            Statement body) {
        assert tokens != null : "Violation of: tokens is not null";
        assert body != null : "Violation of: body is not null";
        assert tokens.length() > 0 && tokens.front().equals("INSTRUCTION") : ""
                + "Violation of: <\"INSTRUCTION\"> is proper prefix of tokens";

        /*
         * dequeues beginning of instruction in order to get to the body and
         * check syntax for them
         */
        tokens.dequeue();
        body.clear();
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");
        String name = tokens.dequeue();
        //checks if name of instruction is a primitive instruction name
        Reporter.assertElseFatalError(
                !(name.equals("move") || name.equals("turnright")
                        || name.equals("turnleft") || name.equals("infect")
                        || name.equals("skip")),
                "Intruction name is name of a primitive intruction name");

        Reporter.assertElseFatalError(tokens.dequeue().equals("IS"),
                "Invalid syntax");
        //add string statements to block of instruction
        body.parseBlock(tokens);
        Reporter.assertElseFatalError(tokens.dequeue().equals("END"),
                "Invalid syntax");
        Reporter.assertElseFatalError(tokens.dequeue().equals(name),
                "Instruction must have the same name at the end");
        return name;
    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Program1Parse1() {
        super();
    }

    /*
     * Public methods ---------------------------------------------------------
     */

    @Override
    public void parse(SimpleReader in) {
        assert in != null : "Violation of: in is not null";
        assert in.isOpen() : "Violation of: in.is_open";
        Queue<String> tokens = Tokenizer.tokens(in);
        this.parse(tokens);
    }

    @Override
    public void parse(Queue<String> tokens) {
        assert tokens != null : "Violation of: tokens is not null";
        assert tokens.length() > 0 : ""
                + "Violation of: Tokenizer.END_OF_INPUT is a suffix of tokens";

        //Check PROGRAM identifier
        Reporter.assertElseFatalError(tokens.dequeue().equals("PROGRAM"),
                "Invalid syntax");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //Extract and check program identifier
        String programName = tokens.dequeue();
        Reporter.assertElseFatalError(Tokenizer.isIdentifier(programName),
                "Invalid syntax");
        Reporter.assertElseFatalError(
                !(programName.equals("move") || programName.equals("turnright")
                        || programName.equals("turnleft")
                        || programName.equals("infect")
                        || programName.equals("skip")),
                "Program name is name of a primitive intruction name");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //Swap program's name
        this.setName(programName);

        //Check for "IS"
        Reporter.assertElseFatalError(tokens.dequeue().equals("IS"),
                "Invalid syntax");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //loop through program body/instructions and add to this
        Map<String, Statement> tempContext = this.newContext();

        while (tokens.front().equals("INSTRUCTION")) {
            Statement tempBody = new Statement1();
            String key = parseInstruction(tokens, tempBody);
            //errors if the instruction is not unique
            Reporter.assertElseFatalError(!tempContext.hasKey(key),
                    key + " is not a unique instruction");
            tempContext.add(key, tempBody);
        }

        //Swap program's context
        this.swapContext(tempContext);

        //Check for "BEGIN"
        Reporter.assertElseFatalError(tokens.dequeue().equals("BEGIN"),
                "Invalid syntax");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //Parse program's body
        Statement tempBody = this.newBody();
        tempBody.parseBlock(tokens);

        //After parsing, you should encounter an "END" and the same program name
        Reporter.assertElseFatalError(tokens.dequeue().equals("END"),
                "Invalid syntax");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");
        Reporter.assertElseFatalError(tokens.dequeue().equals(programName),
                "Program must have the same name at the end");
        Reporter.assertElseFatalError(tokens.length() == 1,
                "End of input expected");

        //Swap program's body
        this.swapBody(tempBody);

    }

    /*
     * Main test method -------------------------------------------------------
     */

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Get input file name
         */
        out.print("Enter valid BL program file name: ");
        String fileName = in.nextLine();
        /*
         * Parse input file
         */
        out.println("*** Parsing input file ***");
        Program p = new Program1Parse1();
        SimpleReader file = new SimpleReader1L(fileName);
        Queue<String> tokens = Tokenizer.tokens(file);
        file.close();
        p.parse(tokens);
        /*
         * Pretty print the program
         */
        out.println("*** Pretty print of parsed program ***");
        p.prettyPrint(out);

        in.close();
        out.close();
    }

}
