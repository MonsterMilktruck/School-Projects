import components.queue.Queue;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.statement.Statement;
import components.statement.Statement1;
import components.utilities.Reporter;
import components.utilities.Tokenizer;

/**
 * Layered implementation of secondary methods {@code parse} and
 * {@code parseBlock} for {@code Statement}.
 *
 * @author Brady Scott & Kevin Haller
 *
 */
public final class Statement1Parse1 extends Statement1 {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Converts {@code c} into the corresponding {@code Condition}.
     *
     * @param c
     *            the condition to convert
     * @return the {@code Condition} corresponding to {@code c}
     * @requires [c is a condition string]
     * @ensures parseCondition = [Condition corresponding to c]
     */
    private static Condition parseCondition(String c) {
        assert c != null : "Violation of: c is not null";
        assert Tokenizer
                .isCondition(c) : "Violation of: c is a condition string";
        return Condition.valueOf(c.replace('-', '_').toUpperCase());
    }

    /**
     * Parses an IF or IF_ELSE statement from {@code tokens} into {@code s}.
     *
     * @param tokens
     *            the input tokens
     * @param s
     *            the parsed statement
     * @replaces s
     * @updates tokens
     * @requires <pre>
     * [<"IF"> is a prefix of tokens]  and
     *  [<Tokenizer.END_OF_INPUT> is a suffix of tokens]
     * </pre>
     * @ensures <pre>
     * if [an if string is a proper prefix of #tokens] then
     *  s = [IF or IF_ELSE Statement corresponding to if string at start of #tokens]  and
     *  #tokens = [if string at start of #tokens] * tokens
     * else
     *  [reports an appropriate error message to the console and terminates client]
     * </pre>
     */
    private static void parseIf(Queue<String> tokens, Statement s) {
        assert tokens != null : "Violation of: tokens is not null";
        assert s != null : "Violation of: s is not null";
        assert tokens.length() > 0 && tokens.front().equals("IF") : ""
                + "Violation of: <\"IF\"> is proper prefix of tokens";

        //Remove "IF"
        tokens.dequeue();
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //Extract, check, and parse condition
        String c = tokens.dequeue();
        Reporter.assertElseFatalError(Tokenizer.isCondition(c),
                "Not a valid condition");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");
        Condition tempCon = parseCondition(c);

        //Check for "THEN"
        Reporter.assertElseFatalError(tokens.dequeue().equals("THEN"),
                "Invalid Syntax");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //Parse IF's block
        Statement tempBlock = s.newInstance();
        tempBlock.parseBlock(tokens);
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //After parsing, you should only encounter an END or ELSE
        if (tokens.front().equals("END")) {
            //Remove "END" and check for "IF" and assemble
            tokens.dequeue();
            Reporter.assertElseFatalError(tokens.dequeue().equals("IF"),
                    "Invalid Syntax");
            s.assembleIf(tempCon, tempBlock);
        } else if (tokens.front().equals("ELSE")) {
            //Remove "ELSE" and parse again for ELSE block
            tokens.dequeue();
            Reporter.assertElseFatalError(tokens.length() > 0,
                    "More tokens expected");
            Statement tempBlock2 = s.newInstance();
            tempBlock2.parseBlock(tokens);

            //Remove "END" and check for "IF" and assemble IF_ELSE
            Reporter.assertElseFatalError(tokens.dequeue().equals("END"),
                    "Invalid Syntax");
            Reporter.assertElseFatalError(tokens.length() > 0,
                    "More tokens expected");
            Reporter.assertElseFatalError(tokens.dequeue().equals("IF"),
                    "Invalid Syntax");
            s.assembleIfElse(tempCon, tempBlock, tempBlock2);
        } else {
            Reporter.assertElseFatalError(false, "Invalid Syntax");
        }

    }

    /**
     * Parses a WHILE statement from {@code tokens} into {@code s}.
     *
     * @param tokens
     *            the input tokens
     * @param s
     *            the parsed statement
     * @replaces s
     * @updates tokens
     * @requires <pre>
     * [<"WHILE"> is a prefix of tokens]  and
     *  [<Tokenizer.END_OF_INPUT> is a suffix of tokens]
     * </pre>
     * @ensures <pre>
     * if [a while string is a proper prefix of #tokens] then
     *  s = [WHILE Statement corresponding to while string at start of #tokens]  and
     *  #tokens = [while string at start of #tokens] * tokens
     * else
     *  [reports an appropriate error message to the console and terminates client]
     * </pre>
     */
    private static void parseWhile(Queue<String> tokens, Statement s) {
        assert tokens != null : "Violation of: tokens is not null";
        assert s != null : "Violation of: s is not null";
        assert tokens.length() > 0 && tokens.front().equals("WHILE") : ""
                + "Violation of: <\"WHILE\"> is proper prefix of tokens";

        //Remove "WHILE"
        tokens.dequeue();
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //Extract, check, and parse condition
        String c = tokens.dequeue();
        Reporter.assertElseFatalError(Tokenizer.isCondition(c),
                "Not a valid condition");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");
        Condition tempCon = parseCondition(c);

        //Check for "DO"
        Reporter.assertElseFatalError(tokens.dequeue().equals("DO"),
                "Invalid Syntax");
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //Parse WHILES's block
        Statement tempBlock = s.newInstance();
        tempBlock.parseBlock(tokens);
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");

        //After parsing, you should only encounter an END and WHILE
        //Remove them and assemble
        Reporter.assertElseFatalError(tokens.front().equals("END"),
                "Expected END");
        tokens.dequeue();
        Reporter.assertElseFatalError(tokens.length() > 0,
                "More tokens expected");
        Reporter.assertElseFatalError(tokens.dequeue().equals("WHILE"),
                "Expected WHILE");

        s.assembleWhile(tempCon, tempBlock);

    }

    /**
     * Parses a CALL statement from {@code tokens} into {@code s}.
     *
     * @param tokens
     *            the input tokens
     * @param s
     *            the parsed statement
     * @replaces s
     * @updates tokens
     * @requires [identifier string is a proper prefix of tokens]
     * @ensures <pre>
     * s =
     *   [CALL Statement corresponding to identifier string at start of #tokens]  and
     *  #tokens = [identifier string at start of #tokens] * tokens
     * </pre>
     */
    private static void parseCall(Queue<String> tokens, Statement s) {
        assert tokens != null : "Violation of: tokens is not null";
        assert s != null : "Violation of: s is not null";
        assert tokens.length() > 0
                && Tokenizer.isIdentifier(tokens.front()) : ""
                        + "Violation of: identifier string is proper prefix of tokens";

        //Extract and assemble name
        String name = tokens.dequeue();
        s.assembleCall(name);

    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Statement1Parse1() {
        super();
    }

    /*
     * Public methods ---------------------------------------------------------
     */

    @Override
    public void parse(Queue<String> tokens) {
        assert tokens != null : "Violation of: tokens is not null";
        assert tokens.length() > 0 : ""
                + "Violation of: Tokenizer.END_OF_INPUT is a suffix of tokens";

        String header = tokens.front();

        //Next header should be IF, WHILE, or a CALL, else error
        if (header.equals("IF")) {
            parseIf(tokens, this);
        } else if (header.equals("WHILE")) {
            parseWhile(tokens, this);
        } else if (Tokenizer.isIdentifier(header)) {
            parseCall(tokens, this);
        } else {
            Reporter.assertElseFatalError(false, "Expected Statement Header");
        }

    }

    @Override
    public void parseBlock(Queue<String> tokens) {
        assert tokens != null : "Violation of: tokens is not null";
        assert tokens.length() > 0 : ""
                + "Violation of: Tokenizer.END_OF_INPUT is a suffix of tokens";

        //Replaces this
        this.clear();

        //Position of statement in block
        int x = 0;

        //Keep running until an encounter that is not a statement
        while (tokens.front().equals("IF") || tokens.front().equals("WHILE")
                || Tokenizer.isIdentifier(tokens.front())) {
            Statement temp = this.newInstance();

            temp.parse(tokens);
            this.addToBlock(x, temp);
            x++;
        }

    }

    /*
     * Main test method -------------------------------------------------------
     */

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Get input file name
         */
        out.print("Enter valid BL statement(s) file name: ");
        String fileName = in.nextLine();
        /*
         * Parse input file
         */
        out.println("*** Parsing input file ***");
        Statement s = new Statement1Parse1();
        SimpleReader file = new SimpleReader1L(fileName);
        Queue<String> tokens = Tokenizer.tokens(file);
        file.close();
        s.parse(tokens); // replace with parseBlock to test other method
        /*
         * Pretty print the statement(s)
         */
        out.println("*** Pretty print of parsed statement(s) ***");
        s.prettyPrint(out, 0);

        in.close();
        out.close();
    }

}
