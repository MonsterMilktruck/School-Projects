import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.map.Map;
import components.map.Map.Pair;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Brady Scott and Kevin Haller
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     * tests constructors
     */
    @Test
    //Routine
    public void constructorTest1() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest();
        Map<String, String> map2 = this.createFromArgsRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map2, map1);
    }

    /**
     * tests constructors
     */
    @Test
    //Routine
    public void constructorTest2() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("your", "mom");
        Map<String, String> map2 = this.createFromArgsRef("your", "mom");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map2, map1);
    }

    /**
     * tests add method
     */
    @Test
    //Routine
    public void testAdd1() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> q = this.createFromArgsTest("p", "o", "o", "p");
        Map<String, String> expectedq = this.createFromArgsRef("p", "o", "o",
                "p", "e", "d");
        /*
         * Calls method
         */
        q.add("e", "d");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
    }

    /**
     * tests add method
     */
    @Test
    //Routine
    public void testAdd2() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("a", "b");
        Map<String, String> map2 = this.createFromArgsRef("a", "b", "c", "d");
        /*
         * Calls method
         */
        map1.add("c", "d");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map2, map1);
    }

    /**
     * tests add method
     */
    @Test
    //Boundary
    public void testAdd3() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> q = this.createFromArgsTest();
        Map<String, String> expectedq = this.createFromArgsRef("ok", "no");
        /*
         * Calls method
         */
        q.add("ok", "no");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
    }

    /**
     * tests add method
     */
    @Test
    //Challenge
    public void testAdd4() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r");
        Map<String, String> map2 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r", "s", "t");
        /*
         * Calls method
         */
        map1.add("s", "t");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map2, map1);
    }

    /**
     * tests remove method
     */
    @Test
    //Routine
    public void testRemove1() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> q = this.createFromArgsTest("ok", "man", "yep",
                "ok");
        Map<String, String> expectedq = this.createFromArgsRef("ok", "man");
        /*
         * Calls method
         */
        Pair<String, String> pairTest = q.remove("yep");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
        assertEquals(pairTest.key(), "yep");
    }

    /**
     * tests remove method
     */
    @Test
    //Boundary
    public void testRemove2() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> q = this.createFromArgsTest("bruh", "yep");
        Map<String, String> expectedq = this.createFromArgsRef();
        /*
         * Calls method
         */
        q.remove("bruh");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
    }

    /**
     * tests remove method
     */
    @Test
    //Challenge
    public void testRemove3() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r", "s", "t");
        Map<String, String> map2 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r");
        /*
         * Calls method
         */
        Pair<String, String> pair1 = map1.remove("s");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(pair1.key(), "s");
        assertEquals(map2, map1);
    }

    /**
     * tests removeAny method
     */
    @Test
    //Routine
    public void testRemoveAny1() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("a", "b", "c", "d");
        Map<String, String> map2 = this.createFromArgsRef("a", "b");
        /*
         * Calls method
         */
        map1.removeAny();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map2.size(), map1.size());
    }

    /**
     * tests removeAny method
     */
    @Test
    //boundary
    public void testRemoveAny2() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("c", "d");
        Map<String, String> map2 = this.createFromArgsRef();
        /*
         * Calls method
         */
        Pair<String, String> pair1 = map1.removeAny();

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map2.size(), map1.size());
        assertEquals(pair1.key(), "c");
    }

    /**
     * tests removeAny method
     */
    @Test
    //Challenge
    public void testRemoveAny3() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r", "s", "t");
        Map<String, String> map2 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r");
        /*
         * Calls method
         */
        map1.removeAny();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map2.size(), map1.size());
    }

    /**
     * tests size method
     */
    @Test
    //Routine
    public void testSize1() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> q = this.createFromArgsTest("why", "man");
        Map<String, String> expectedq = this.createFromArgsRef("why", "man");

        /*
         * Assert that values of sizes match each other
         */
        assertEquals(expectedq.size(), q.size());
    }

    /**
     * tests size method
     */
    @Test
    //Boundary
    public void testSize2() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest();
        Map<String, String> map2 = this.createFromArgsRef();
        /*
         * Assert that values of sizes match the numbers
         */
        assertEquals(map2.size(), map1.size());
    }

    /**
     * tests value method
     */
    @Test
    //Routine
    public void testValue1() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> q = this.createFromArgsTest("go", "bucks");
        Map<String, String> expectedq = this.createFromArgsRef("go", "bucks");
        String expectedS = "bucks";
        /*
         * Calls method
         */
        String S = q.value("go");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expectedq, q);
        assertEquals(expectedS, S);
    }

    /**
     * tests value method
     */
    @Test
    //Challenge
    public void testValue2() {
        Map<String, String> map1 = this.createFromArgsTest("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r", "s", "t");
        Map<String, String> map2 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r", "s", "t");
        /*
         * Calls method
         */
        String test = map1.value("k");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map2, map1);
        assertEquals("l", test);
    }

    /**
     * tests hasKey method
     */
    @Test
    //Routine
    public void testHasKey1() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> q = this.createFromArgsTest("go", "back", "to",
                "michagan");
        Map<String, String> expectedq = this.createFromArgsRef("go", "back",
                "to", "michagan");
        /*
         * Calls method
         */
        boolean test = q.hasKey("to");
        /*
         * Assert that values of variables match expectations
         */

        assertEquals(expectedq, q);
        assertTrue(test);
    }

    /*
     * tests hasKey method
     */
    @Test
    //Routine
    public void testHasKey2() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("a", "b");
        Map<String, String> map2 = this.createFromArgsRef("a", "b");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map1, map2);
        assertFalse(map1.hasKey("e"));
    }

    /*
     * tests hasKey method
     */
    @Test
    //Boundary
    public void testHasKey3() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest();
        Map<String, String> map2 = this.createFromArgsRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map1, map2);
        assertFalse(map1.hasKey("dude"));
    }

    /*
     * tests hasKey method
     */
    @Test
    //Challenge
    public void testHasKey4() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map1 = this.createFromArgsTest("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r", "s", "t");
        Map<String, String> map2 = this.createFromArgsRef("a", "b", "c", "d",
                "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
                "r", "s", "t");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(map1, map2);
        assertTrue(map1.hasKey("m"));
    }
}
