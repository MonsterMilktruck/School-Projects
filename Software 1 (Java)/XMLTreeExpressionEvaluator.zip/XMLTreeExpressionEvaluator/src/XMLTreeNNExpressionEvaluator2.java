import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.Reporter;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code int}.
 *
 * @author Brady Scott
 *
 */
public final class XMLTreeNNExpressionEvaluator2 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeNNExpressionEvaluator2() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static NaturalNumber evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";
        NaturalNumber temp = new NaturalNumber1L(0);
        NaturalNumber temp2 = new NaturalNumber1L(0);
        boolean filled = false;
        /*
         * iterates through the xml tree's children
         */
        for (int i = 0; i < exp.numberOfChildren(); i++) {
            /*
             * if the child's name is number it takes the value as a natural
             * number
             */
            if (exp.child(i).label().equals("number")) {
                temp = new NaturalNumber1L(
                        exp.child(i).attributeValue("value"));
                /*
                 * if the temp2 value is empty (i.e. it is the first number
                 * found in the xml tree) it transfers the value over (by
                 * replicating the pointer to it) so that it can determine a new
                 * value
                 */
                if (!filled) {
                    temp2 = temp;
                    filled = true;
                }
                /*
                 * if the value of temp2 is already filled then the program
                 * determines the value of the expression (because both numbers
                 * have been determined) and then copies temp from temp2
                 */
                else {
                    if (exp.label().equals("plus")) {
                        temp2.add(temp);
                        temp.copyFrom(temp2);
                    } else if (exp.label().equals("minus")) {
                        if (temp.compareTo(temp2) > 0) {
                            Reporter.fatalErrorToConsole(
                                    "ERROR! the resulting natural number would be negative!");
                        }
                        temp2.subtract(temp);
                        temp.copyFrom(temp2);
                    } else if (exp.label().equals("times")) {
                        temp2.multiply(temp);
                        temp.copyFrom(temp2);
                    } else {
                        if (temp.isZero()) {
                            Reporter.fatalErrorToConsole(
                                    "ERROR! cannot divide by zero!");
                        }
                        temp2.divide(temp);
                        temp.copyFrom(temp2);
                    }
                }
            }
            /*
             * if the xml tree's child is an expression then the code recursivly
             * calls itself in order to find the number that needs to be
             * calculated
             */
            else if (exp.child(i).label().equals("plus")
                    || exp.child(i).label().equals("minus")
                    || exp.child(i).label().equals("divide")
                    || exp.child(i).label().equals("times")) {
                temp = evaluate(exp.child(i));
                /*
                 * if the temp2 value is empty (i.e. it is the first number
                 * found in the xml tree) it transfers the value over (by
                 * replicating the pointer to it) so that it can determine a new
                 * value
                 */
                if (!filled) {
                    temp2 = temp;
                    filled = true;
                }
                /*
                 * if the value of temp2 is already filled then the program
                 * determines the value of the expression (because both numbers
                 * have been determined) and then copies temp from temp2
                 */
                else {
                    if (exp.label().equals("plus")) {
                        if (temp.compareTo(temp2) > 0) {
                            Reporter.fatalErrorToConsole(
                                    "ERROR! the resulting natural number would be negative!");
                        }
                        temp2.add(temp);
                        temp.copyFrom(temp2);
                    } else if (exp.label().equals("minus")) {
                        temp2.subtract(temp);
                        temp.copyFrom(temp2);
                    } else if (exp.label().equals("times")) {
                        temp2.multiply(temp);
                        temp.copyFrom(temp2);
                    } else {
                        if (temp.isZero()) {
                            Reporter.fatalErrorToConsole(
                                    "ERROR! cannot divide by zero!");
                        }
                        temp2.divide(temp);
                        temp.copyFrom(temp2);
                    }
                }
            }
        }
        return temp;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}