import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code int}.
 *
 * @author Brady Scott
 *
 */
public final class XMLTreeIntExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeIntExpressionEvaluator() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static int evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";
        int temp = 0;
        int temp2 = 0;
        boolean filled = false;
        /*
         * iterates through the xml tree's children
         */
        for (int i = 0; i < exp.numberOfChildren(); i++) {
            /*
             * if the child's name is number it takes the value as an int
             */
            if (exp.child(i).label().equals("number")) {
                temp = Integer.parseInt(exp.child(i).attributeValue("value"));
                /*
                 * if the temp2 value is empty (i.e. it is the first number
                 * found in the xml tree) it transfers the value over so that it
                 * can determine a new value
                 */
                if (!filled) {
                    temp2 = temp;
                    filled = true;
                }
                /*
                 * if the value of temp2 is already filled then the program
                 * determines the value of the expression (because both numbers
                 * have been determined)
                 */
                else {
                    if (exp.label().equals("plus")) {
                        temp = temp2 + temp;
                    } else if (exp.label().equals("minus")) {
                        temp = temp2 - temp;
                    } else if (exp.label().equals("times")) {
                        temp = temp2 * temp;
                    } else {
                        temp = temp2 / temp;
                    }
                }
            }
            /*
             * if the xml tree's child is an expression then the code recursivly
             * calls itself in order to find the number that needs to be
             * calculated
             */
            else if (exp.child(i).label().equals("plus")
                    || exp.child(i).label().equals("minus")
                    || exp.child(i).label().equals("divide")
                    || exp.child(i).label().equals("times")) {
                temp = evaluate(exp.child(i));
                /*
                 * if the temp2 value is empty (i.e. it is the first number
                 * found in the xml tree) it transfers the value over so that it
                 * can determine a new value
                 */
                if (!filled) {
                    temp2 = temp;
                    filled = true;
                }
                /*
                 * if the value of temp2 is already filled then the program
                 * determines the value of the expression (because both numbers
                 * have been determined)
                 */
                else {
                    if (exp.label().equals("plus")) {
                        temp = temp2 + temp;
                    } else if (exp.label().equals("minus")) {
                        temp = temp2 - temp;
                    } else if (exp.label().equals("times")) {
                        temp = temp2 * temp;
                    } else {
                        temp = temp2 / temp;
                    }
                }
            }
        }
        return temp;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}