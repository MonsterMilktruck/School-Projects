import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * @author Brady Scott
 *
 */
public class CryptoUtilitiesTest {

    /*
     * Tests of reduceToGCD
     */

    @Test
    public void testReduceToGCD_0_0() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(0);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    @Test
    public void testReduceToGCD_30_21() {
        NaturalNumber n = new NaturalNumber2(30);
        NaturalNumber nExpected = new NaturalNumber2(3);
        NaturalNumber m = new NaturalNumber2(21);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    /*
     * boundary case
     */

    @Test
    public void testReduceToGCD_19239139123_345345352() {
        NaturalNumber n = new NaturalNumber2("19239139123");
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber m = new NaturalNumber2("345345352");
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    /*
     * Tests of isEven
     */

    @Test
    public void testIsEven_0() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(0);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsEven_1() {
        NaturalNumber n = new NaturalNumber2(1);
        NaturalNumber nExpected = new NaturalNumber2(1);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * boundary case (odd)
     */

    @Test
    public void testIsEven_1123123213123() {
        NaturalNumber n = new NaturalNumber2("1123123213123");
        NaturalNumber nExpected = new NaturalNumber2("1123123213123");
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * boundary case (even)
     */

    @Test
    public void testIsEven_10000000000() {
        NaturalNumber n = new NaturalNumber2("10000000000");
        NaturalNumber nExpected = new NaturalNumber2("10000000000");
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    /*
     * Tests of powerMod
     */

    @Test
    public void testPowerMod_0_0_2() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(0);
        NaturalNumber pExpected = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(2);
        NaturalNumber mExpected = new NaturalNumber2(2);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    @Test
    public void testPowerMod_17_18_19() {
        NaturalNumber n = new NaturalNumber2(17);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(18);
        NaturalNumber pExpected = new NaturalNumber2(18);
        NaturalNumber m = new NaturalNumber2(19);
        NaturalNumber mExpected = new NaturalNumber2(19);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * routine case
     */
    @Test
    public void testPowerMod_3_2_5() {
        NaturalNumber n = new NaturalNumber2(3);
        NaturalNumber nExpected = new NaturalNumber2(4);
        NaturalNumber p = new NaturalNumber2(2);
        NaturalNumber pExpected = new NaturalNumber2(2);
        NaturalNumber m = new NaturalNumber2(5);
        NaturalNumber mExpected = new NaturalNumber2(5);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * boundary case / challenging case
     */
    @Test
    public void testPowerMod_123912391_123123_23() {
        NaturalNumber n = new NaturalNumber2(123912391);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(123123);
        NaturalNumber pExpected = new NaturalNumber2(123123);
        NaturalNumber m = new NaturalNumber2(23);
        NaturalNumber mExpected = new NaturalNumber2(23);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * routine case
     */
    @Test
    public void testPowerMod_12_4_3() {
        NaturalNumber n = new NaturalNumber2(12);
        NaturalNumber nExpected = new NaturalNumber2(0);
        NaturalNumber p = new NaturalNumber2(4);
        NaturalNumber pExpected = new NaturalNumber2(4);
        NaturalNumber m = new NaturalNumber2(3);
        NaturalNumber mExpected = new NaturalNumber2(3);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * routine case
     */
    @Test
    public void testPowerMod_90_5_18() {
        NaturalNumber n = new NaturalNumber2(90);
        NaturalNumber nExpected = new NaturalNumber2(0);
        NaturalNumber p = new NaturalNumber2(5);
        NaturalNumber pExpected = new NaturalNumber2(5);
        NaturalNumber m = new NaturalNumber2(18);
        NaturalNumber mExpected = new NaturalNumber2(18);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * tests isWitnessToCompositeness
     */
    @Test
    public void testIsWitnessToCompositeness_3_6() {
        NaturalNumber n = new NaturalNumber2(3);
        NaturalNumber nExpected = new NaturalNumber2(3);
        NaturalNumber m = new NaturalNumber2(6);
        NaturalNumber mExpected = new NaturalNumber2(6);
        boolean result = CryptoUtilities.isWitnessToCompositeness(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
        assertEquals(true, result);
    }

    /*
     * boundary case
     */
    @Test
    public void testIsWitnessToCompositeness_2_4() {
        NaturalNumber n = new NaturalNumber2(2);
        NaturalNumber nExpected = new NaturalNumber2(2);
        NaturalNumber m = new NaturalNumber2(4);
        NaturalNumber mExpected = new NaturalNumber2(4);
        boolean result = CryptoUtilities.isWitnessToCompositeness(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
        assertEquals(true, result);
    }

    /*
     * boundary case
     */

    @Test
    public void testIsWitnessToCompositeness_100000000000000000000_11111111112313123123() {
        NaturalNumber n = new NaturalNumber2("100000000000000000000");
        NaturalNumber nExpected = new NaturalNumber2("100000000000000000000");
        NaturalNumber m = new NaturalNumber2("111111111123131231231231233123");
        NaturalNumber mExpected = new NaturalNumber2(
                "111111111123131231231231233123");
        boolean result = CryptoUtilities.isWitnessToCompositeness(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
        assertEquals(true, result);
    }

    /*
     * tests isPrime1 - boundary case
     */

    @Test
    public void testIsPrime1_100000000000000000000() {
        NaturalNumber n = new NaturalNumber2("100000000000000000000");
        NaturalNumber nExpected = new NaturalNumber2("100000000000000000000");
        boolean result = CryptoUtilities.isPrime1(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * boundary case
     */

    @Test
    public void testIsPrime1_1() {
        NaturalNumber n = new NaturalNumber2("2");
        NaturalNumber nExpected = new NaturalNumber2("2");
        boolean result = CryptoUtilities.isPrime1(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    /*
     * tests isPrime2 - boundary case
     */

    @Test
    public void testIsPrime2_100000000000000000000() {
        NaturalNumber n = new NaturalNumber2("100000000000000000000");
        NaturalNumber nExpected = new NaturalNumber2("100000000000000000000");
        boolean result = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * boundary case
     */

    @Test
    public void testIsPrime2_1() {
        NaturalNumber n = new NaturalNumber2("2");
        NaturalNumber nExpected = new NaturalNumber2("2");
        boolean result = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    /*
     * tests generateNextLikelyPrime - boundary case
     */

    @Test
    public void testGenerateNextLikelyPrime_100000000000000000000() {
        NaturalNumber n = new NaturalNumber2("100000000000000000000");
        NaturalNumber nExpected = new NaturalNumber2("100000000000000000039");
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals(nExpected, n);
    }

    /*
     * boundary case
     */

    @Test
    public void testGenerateNextLikelyPrime_1() {
        NaturalNumber n = new NaturalNumber2("2");
        NaturalNumber nExpected = new NaturalNumber2("3");
        CryptoUtilities.generateNextLikelyPrime(n);
        assertEquals(nExpected, n);
    }
}