import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Determines a square root that the user specifies by using Newton iteration.
 *
 * @author Brady Scott
 *
 */
public final class Newton3 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Newton3() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @param errorAmount
     *            amount of allowed error specified
     * @return estimate of square root
     */
    private static double sqrt(double x, double errorAmount) {
        double squareRoot = x;
        if (x != 0) {
            while (Math.abs(
                    Math.pow(squareRoot, 2) - x) > (Math.pow(errorAmount, 2))) {
                /**
                 * repeats the loop if the margin of error for the square root
                 * value is over .01%
                 */

                squareRoot = (squareRoot + (x / squareRoot)) / 2;
                /**
                 * calculates the square root by using Newton iteration ^
                 */
            }
        }
        return squareRoot;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        char repeat = 'y';

        out.print(
                "What would you like the upmost limit of error to be (in decimal)? ");
        double error = in.nextDouble();
        /*
         * user inputs the amount of error they would like the program to allow
         */
        while (repeat == 'y') {
            //repeats if the user's answer is 'y'
            out.print(
                    "What is your value that you want the square root taken out of? ");
            double userInput = in.nextDouble();
            /**
             * gets user's number
             */
            out.println("The answer is: " + sqrt(userInput, error));
            /**
             * computes square root
             */
            out.print("Would you like to calculate another square root? ");
            repeat = in.nextLine().charAt(0);
            /**
             * user inputs whether they want to try another or not
             */
        }
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
